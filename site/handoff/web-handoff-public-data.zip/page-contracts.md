# 知遇测评：现有页面开发契约

基线 481e89aa67620c04c6a990bfb70509db587bffe1；39 route；299个页面/弹层按钮语义组；146个代表性合成渲染状态。
本文件只描述核对事实与待开发契约，不是生产实现或全量验收。LocalStorage不是正式APP方案。
所有发布题库默认随安装本地；真实内容许可/计分/AI/身份/云保存未就绪不得假称可用。

## 认识 · home

- 主线：入口→作答→回看
- 最小价值：决定开始哪条探索或续接原任务
- 前置：无登录要求；正式题库的使用资格须先成立
- 出入与返回：启动及四TAB；原版→question/review；其他五入口各自路由
- 当前边界：原版当前仅3题原创演示；AI重置不可开始；同级入口不等于同等效度
- 实际/计划状态：首次, 进行中答卷, 已完成, 有小尝试

### 按钮与事件

- start · 交互示例16PF 原版3题示例，不计分正式题源待接入查看作答体验：beginSession已有in-progress即续同ID；否则新建3题demo session并本机commit后question；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 待开放AI 重置版内容、计分与效度待验证查看设计预览：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 单因子测评从16因子选一个：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 每日打卡每天3–5题的设计：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 简化版16PF少量情境题 · 非标准测试：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 模拟性格手动设置 · 假设探索：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- tab · 认识：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- tab · 探索：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- tab · 助理：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- tab · 我的：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- resume · 交互示例16PF 原版3题示例，不计分正式题源待接入继续上次作答：取activeSession，存在才跳question?id；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 回看自己的小尝试审计用虚构小尝试：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 交互示例16PF 原版3题示例，不计分正式题源待接入回看这次作答：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- start-new · 再体验一次原版示例：beginSession已有in-progress即续同ID；否则新建3题demo session并本机commit后question；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- home.local-interaction [local] 页面进入、输入或本人点击本页现有操作。请求：本页明确对象ID/版本及必要字段；返回：本机内容或保存/恢复状态
- 本地 页面上下文：现有 route,params{id,topic,kind,tab},stack,scrolls,recordFilter,exploreCategory,exploreSearch,returnAfterAuth,checkoutReturn；计划 route/objectId/returnIntent/scrollAnchor；正文不进URL；本机UI上下文；内存与偏好保存边界由工程定；不需云端
- 本地 答卷：现有 id,kind,version,mode,status,index,answers{questionId:optionId},createdAt,updatedAt,updatedLabel,activeSession；计划 spaceId/sessionId/assessmentId/contentVersion/scoringVersion/answerRevision/saveState/submitToken/resultId?；本机个人空间；完成后只读快照；保留时长与清理策略待D-08，云副本不是默认
- 本地 小尝试与实际回看：现有 id,text,revision,status,sourceId,sourceKind,sourceVersion,sourceSnapshot,sectionId,reviews{id,outcome,text,actionText,actionRevision,createdAt},createdAt；计划 spaceId/actionId/reviewId/sourceRevision/reviewSubmitToken；本机本人决定；计划与实际观察独立；修改计划不改历史回看；提醒额外授权后才启用
- 本地 题库/阅读/专题包：现有 D.questions{3个原创questionId,title,options}；D.topics{5个topicId,category,prompts}；D.report；D.factors；均随JS静态提供；计划 packId/contentVersion/assessmentId/questionId/optionId/licenseEvidence/eligibilityStatus/scoringVersion/normVersion/checksum；全部发布题库默认随安装本地；首启不依赖下载。资格不成立不分发正式内容；更新/撤回保留旧任务版本。更新服务如启用仅请求包和版本元数据
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-001, ZY-FR-002, ZY-FR-007, ZY-FR-014, ZY-FR-015, ZY-FR-016, ZY-FR-057
- 验收ID：T-FR-001-N, T-FR-001-E1, T-FR-001-E2, T-FR-001-R1-UI, T-FR-002-N, T-FR-002-E1, T-FR-002-E2, T-FR-002-R1-ENTRY, T-FR-007-N, T-FR-007-E1, T-FR-007-E2, T-FR-007-E3, T-FR-014-N, T-FR-014-E1, T-FR-014-E2, T-FR-014-R1-SELECT, T-FR-015-N, T-FR-015-E1, T-FR-015-E2, T-FR-015-R1-RANGE, T-FR-015-R1-COLD, T-FR-015-R1-PROFILE, T-FR-015-R3-DAILY-1, T-FR-015-R3-DAILY-2, T-FR-015-R3-DAILY-3, T-FR-015-R3-QUESTION, T-FR-015-R3-DEVICES, T-FR-016-N, T-FR-016-E1, T-FR-016-E2, T-FR-016-R1-SIM, T-FR-057-N, T-FR-057-E1, T-FR-057-E2
- 待决：D-02 16PF题源与授权（产品负责人，必要时由测量/法律/工程专业方协助）；D-03 AI重置版身份（产品负责人，必要时由测量/法律/工程专业方协助）；D-04 计分常模与适用性（产品负责人，必要时由测量/法律/工程专业方协助）；D-05 首版完整价值切片（产品负责人，必要时由测量/法律/工程专业方协助）；D-08 空间、留存与备份（产品负责人，必要时由测量/法律/工程专业方协助）；D-16 内容与支持运营（产品负责人，必要时由测量/法律/工程专业方协助）；D-17 每日选题与画像更新策略（产品负责人，必要时由测量/内容/工程专业方协助）；D-18 简化版内容映射与测量依据（产品负责人，必要时由测量/内容/工程专业方协助）；D-19 模拟性格量尺与假设分析（产品负责人，必要时由测量/内容/工程专业方协助）

## 探索 · explore

- 主线：现实问题→专题→本人整理
- 最小价值：找一个生活议题并保留兴趣
- 前置：本地浏览无账号；专题为原创自助框架
- 出入与返回：四TAB；topic→topic-workspace；返回保留搜索与分类
- 当前边界：现在只有5个专题；收藏弹层，非独立收藏页；未知主题不能替换默认主题
- 实际/计划状态：全部, 分类, 有关键词, 无结果, 有旧整理

### 按钮与事件

- favorites · 收藏：打开收藏主题列表或空说明；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- clear-search · 筛选说明 / 清空搜索：清空搜索/分类重绘；空搜索按钮显示筛选说明；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- category · 全部 / 工作 / 相处 / 学习 / 生活：更新本机筛选状态并重绘；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 工作 · 4 个问题留下，还是换个方向？把期待与现实放在一起。一份选择清单? / 相处 · 3 个问题把需要，说清楚从一件具体的事开始。一句具体表达 / 生活 · 4 个问题哪里更适合生活？先看条件，再看向往。一份条件清单 / 学习 · 3 个问题找回学习的理由分清期待与外界的声音。一次学习实验 / 生活 · 3 个问题一个人，刚刚好？观察独处前后的变化。一条情境观察：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 整理工作议题 / 继续这份整理：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- daily · 每日轻探索从一个小问题开始：打开旧每日概念说明；可跳journal?kind=daily；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- all-factors · 单因子探索一次了解一个角度：展示16因子弹层；sim-factors设置选择模式；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 假设实验理解概念，不生成个人结论：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 报告样例独立虚构样例，非本人结果：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 如何理解因子高一点、低一点，都不代表更好：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- tab · 认识：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- tab · 探索：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- tab · 助理：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- tab · 我的：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- clear-filters · 清空筛选：清空搜索/分类重绘；空搜索按钮显示筛选说明；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 已收藏主题的标题：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 给今天留一句话：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- close-dialog · 先返回：关闭弹层、解除inert/滚动锁、回焦点；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- factor · {factorId} 因子说明：若sim-factors选模式则更新内存simFactor；否则展示该因子样例/未知与边界；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- factor-sim · 用这个角度做个假设：内存simFactor=id，跳旧simulation；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- close-dialog · 回到刚才的位置：关闭弹层、解除inert/滚动锁、回焦点；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- explore.local-interaction [local] 页面进入、输入或本人点击本页现有操作。请求：本页明确对象ID/版本及必要字段；返回：本机内容或保存/恢复状态
- 本地 页面上下文：现有 route,params{id,topic,kind,tab},stack,scrolls,recordFilter,exploreCategory,exploreSearch,returnAfterAuth,checkoutReturn；计划 route/objectId/returnIntent/scrollAnchor；正文不进URL；本机UI上下文；内存与偏好保存边界由工程定；不需云端
- 本地 专题收藏：现有 favorites[topicId]；计划 spaceId/topicId/savedAt/contentVersion?；当前本机；不需云；跨端同步候选未定
- 本地 题库/阅读/专题包：现有 D.questions{3个原创questionId,title,options}；D.topics{5个topicId,category,prompts}；D.report；D.factors；均随JS静态提供；计划 packId/contentVersion/assessmentId/questionId/optionId/licenseEvidence/eligibilityStatus/scoringVersion/normVersion/checksum；全部发布题库默认随安装本地；首启不依赖下载。资格不成立不分发正式内容；更新/撤回保留旧任务版本。更新服务如启用仅请求包和版本元数据
- 本地 本人观察与专题整理：现有 id,kind,topicId,title,fields,text,revision,revisions{revision,fields,text,createdAt},sourceId,sourceKind,sectionId,createdAt,updatedAt；计划 ownerSpaceId/recordId/sourceRefs/currentRevision/explicitConsent；自述与测量事实分别标识；本人本机；历史修订保留；删除同时处理草稿与关联来源全文，已导出副本不可撤回
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-003, ZY-FR-017, ZY-FR-019, ZY-FR-033
- 验收ID：T-FR-003-N, T-FR-003-E1, T-FR-003-E2, T-FR-017-N, T-FR-017-E1, T-FR-017-E2, T-FR-019-N, T-FR-019-E1, T-FR-019-E2, T-FR-033-N, T-FR-033-E1, T-FR-033-E2
- 待决：D-05 首版完整价值切片（产品负责人，必要时由测量/法律/工程专业方协助）

## 助理 · assistant

- 主线：问题草稿→显式引用→AI任务→行动
- 最小价值：准备具体问题、选择资料、决定发送
- 前置：访客可写草稿但AI为0；登录非会员分析+chat共用10/日跨设备
- 出入与返回：四TAB；发送前auth；成功conversation；取消认证回同草稿
- 当前边界：当前本机演示计数+预写回复；无真实模型、账号或服务端计量
- 实际/计划状态：无对话, 有历史, 草稿, 引用, 未登录, 额度耗尽

### 按钮与事件

- context · 选择本次资料 / 已选 1 份资料：V2列最近本人记录/确认记忆；样例在独立details，选择不自动发送；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- send · 登录后继续 / 发送演示：空文阻止；访客→auth保留returnAfterAuth；用尽保留草稿；生成中拒绝重复；引用有效后本机存消息+used++；650ms回预写文本；当前真实出网=无；计划位置=cloud；同名操作语义保留；正式实现尚未接入/验证
- prompt · 理清最近一件事：recent仅在空assistantDraft填示例句并聚焦；report开资料选择；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- quota · 登录后共享 10 次 / 天 / 演示剩余 10 / 10：本机演示used与10剩余说明，内含usage弹层入口；当前真实出网=无；计划位置=cloud；同名操作语义保留；正式实现尚未接入/验证
- nav · 全部对话：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 助理记住了什么查看、修改或停用：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- tab · 认识：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- tab · 探索：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- tab · 助理：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- tab · 我的：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- remove-source · 移除本次引用：从assistantSources或conversation.draftSources移除；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 虚构对话2 条消息 · 本机：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- v2-pick-context · 选择具体本人记录/已确认记忆/独立样例：校验选中source有效，加入当前草稿，关闭弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- close-dialog · 取消选择：关闭弹层、解除inert/滚动锁、回焦点；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- close-dialog · 保留草稿，继续看看：关闭弹层、解除inert/滚动锁、回焦点；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 了解使用与会员规则：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 查看用量明细：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- close-dialog · 继续原来的任务：关闭弹层、解除inert/滚动锁、回焦点；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- ai.request.submit [cloud] 本人点击发送且鉴权/额度/引用通过。请求：logicalRequestId,kind,text,explicitSourceSnapshots,retentionChoice；返回：request状态/输出/来源/结算事实
- quota.read [cloud] 发送前或本人查看用量。请求：accountId,dayKey；返回：共享used/remaining/policyVersion
- 本地 对话与AI请求：现有 assistantDraft,assistantSources；conversations{id,title,persist,draft,draftSources,messages,generating,requestId,pendingRequest,interrupted,updatedLabel}；message{id,role,text,sources,requestId,createdAt,status}；计划 accountId/spaceId/conversationId/messageId/logicalRequestId/operationKind/sourceSnapshotId/status/sequence/retentionScope；草稿本机；非留存对话仅内存。真实AI外发所选正文至明确供应方/云服务；服务端与供应商留存期D-06/08未定，不能承诺零留存
- 本地 本次引用/来源快照：现有 id,kind,objectId,version,sectionId,title,excerpt,status,scope；计划 ownerSpaceId/sourceRef/objectRevision/selectedScope/executedSnapshot/revocationState；草稿引用可移除；正式发送先校验来源与版本；历史执行快照和当前可用状态分开；不自动读取全部历史
- 本地 AI用量账本：现有 used,usageDay,usage{id,kind,status,createdAt}；全部本机演示可绕过；计划 accountId/dayKey/logicalRequestId/kind/settlementState/quotaPolicyVersion/used/remaining；真实额度云端按账号跨设备统一；访客0，登录非会员分析+chat合计10/日；升级、到期、退款不重置已用量；日界线和失败/停止结算D-07未决
- 本地 身份/关联/会话：现有 仅logged布尔，无密码验证码和真实账号；计划 accountId/providerSubject映射/verifiedPhone关联/sessionStatus/consentVersion/spaceClaimChoice/abuseEvidence最小集；认证与共享额度必须云权威；验证码不明文留存；令牌安全系统存储方案待定；本机资料认领不等于云上传
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-020, ZY-FR-022, ZY-FR-023, ZY-FR-024, ZY-AI-004, ZY-DATA-002
- 验收ID：T-FR-020-N, T-FR-020-E1, T-FR-020-E2, T-FR-020-E3, T-FR-022-N, T-FR-022-E1, T-FR-022-E2, T-FR-022-E3, T-FR-023-N, T-FR-023-E1, T-FR-023-E2, T-FR-023-E3, T-FR-023-R2-SHARED, T-FR-023-R3-DAILYAI-1, T-FR-023-R3-DAILYAI-2, T-FR-023-R3-DAILYAI-3, T-FR-023-R3-DAILYAI-4, T-FR-024-N, T-FR-024-E1, T-FR-024-E2, T-FR-024-E3, T-AI-004, T-AI-004-R3-KEY, T-AI-004-R3-DAY, T-DATA-002, T-LEG-05
- 待决：D-06 AI供应商与数据用途（产品负责人，必要时由测量/法律/工程专业方协助）；D-07 共享次数与计量（产品负责人，必要时由测量/法律/工程专业方协助）；D-08 空间、留存与备份（产品负责人，必要时由测量/法律/工程专业方协助）；D-14 设备与质量目标（产品负责人，必要时由测量/法律/工程专业方协助）；D-17 每日选题与画像更新策略（产品负责人，必要时由测量/内容/工程专业方协助）；D-21 账号关联与防重复领额度（产品负责人，开发接入时与工程核验）

## 我的 · me

- 主线：找回资料→个人控制
- 最小价值：找回记录、尝试、设置与身份
- 前置：无需登录查看当前本机空间
- 出入与返回：四TAB；分类入口携带filter，记录携带id/topic
- 当前边界：数量是对象数，不是成长分；修改称呼仅本机显示名
- 实际/计划状态：无资料, 有记录, 有尝试, 演示登录

### 按钮与事件

- edit-name · 修改称呼：表单更新name前20字符；仅本机显示名；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 记一个自己的时刻：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 正在认识的自己来源与留白：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 助理记忆确认与纠正：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 我的数据查看与导出：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 隐私与引用分开控制：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 登录与账号本机记录不要求登录：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 找回全部记录本人观察、专题与体验答卷 / 3本人记录 / 1体验答卷：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 设置主题、形象与阅读习惯：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 会员与使用次数方案、规则与原订单：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- tab · 认识：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- tab · 探索：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- tab · 助理：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- tab · 我的：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 1小尝试：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 打开记录：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 这件小事，还可以回看审计用虚构小尝试：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 演示账号尚未接入真实认证服务：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- submit-dialog · 保存到本机：调用当前dialogCallback；submit先trim且不能为空；confirm先关闭再执行；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- me.local-interaction [local] 页面进入、输入或本人点击本页现有操作。请求：本页明确对象ID/版本及必要字段；返回：本机内容或保存/恢复状态
- 本地 展示与隐私偏好：现有 name,avatar,avatarFamily,theme,density,fontSize,reduced,workspaceMode,chatRetention,memoryEnabled；不含真实画像；计划 settingsVersion/ownerScope/accessibilityOverrides/consentVersions；与推断画像分离；本机展示偏好；云同步若选用须明确字段；关闭留存只作用后续会话，不伪称删历史
- 本地 本人观察与专题整理：现有 id,kind,topicId,title,fields,text,revision,revisions{revision,fields,text,createdAt},sourceId,sourceKind,sectionId,createdAt,updatedAt；计划 ownerSpaceId/recordId/sourceRefs/currentRevision/explicitConsent；自述与测量事实分别标识；本人本机；历史修订保留；删除同时处理草稿与关联来源全文，已导出副本不可撤回
- 本地 答卷：现有 id,kind,version,mode,status,index,answers{questionId:optionId},createdAt,updatedAt,updatedLabel,activeSession；计划 spaceId/sessionId/assessmentId/contentVersion/scoringVersion/answerRevision/saveState/submitToken/resultId?；本机个人空间；完成后只读快照；保留时长与清理策略待D-08，云副本不是默认
- 本地 小尝试与实际回看：现有 id,text,revision,status,sourceId,sourceKind,sourceVersion,sourceSnapshot,sectionId,reviews{id,outcome,text,actionText,actionRevision,createdAt},createdAt；计划 spaceId/actionId/reviewId/sourceRevision/reviewSubmitToken；本机本人决定；计划与实际观察独立；修改计划不改历史回看；提醒额外授权后才启用
- 本地 页面上下文：现有 route,params{id,topic,kind,tab},stack,scrolls,recordFilter,exploreCategory,exploreSearch,returnAfterAuth,checkoutReturn；计划 route/objectId/returnIntent/scrollAnchor；正文不进URL；本机UI上下文；内存与偏好保存边界由工程定；不需云端
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-036, ZY-FR-011, ZY-FR-031, ZY-FR-026, ZY-DATA-003
- 验收ID：T-FR-036-N, T-FR-036-E1, T-FR-036-E2, T-FR-011-N, T-FR-011-E1, T-FR-011-E2, T-FR-031-N, T-FR-031-E1, T-FR-031-E2, T-FR-026-N, T-FR-026-E1, T-FR-026-E2, T-FR-026-E3, T-FR-026-R1-SOURCE, T-DATA-003, T-DATA-003-R3-INTERRUPT, T-DATA-003-R3-SWITCH
- 待决：D-05 首版完整价值切片（产品负责人，必要时由测量/法律/工程专业方协助）；D-08 空间、留存与备份（产品负责人，必要时由测量/法律/工程专业方协助）；D-17 每日选题与画像更新策略（产品负责人，必要时由测量/内容/工程专业方协助）

## 专心作答 · question

- 主线：固定题库版本→答题保存→检查
- 最小价值：回答一题且明确已保存
- 前置：sessionId存在、版本匹配、题项可用；本机答题不以登录为前提
- 出入与返回：home/records/review→question?id；下一题末尾→review；暂停→home
- 当前边界：仅3题演示；已完成答卷在handler拒绝修改，但直接question深链仍渲染可选样式，正式APP须统一只读
- 实际/计划状态：未选择, 已保存, 保存失败, 末题, 缺失对象, 已完成只读约束

### 按钮与事件

- back · 返回：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 回到列表：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- question-prev · 上一题：检查待保存/当前答案后更新index；末题转review；当前硬编码0–2；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- question-next · 下一题 / 检查这次作答：检查待保存/当前答案后更新index；末题转review；当前硬编码0–2；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- pause · 暂停：无pending则确认保留已存位置回home；pending时留在答题恢复面板；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- answer · A确认哪些条件变了，再调整安排 / B先试试新的方向，在过程中调整 / 先听听相关的人有什么想法已选择 / 先写下几个要点，想清楚再表达已选择 / B先找一个人聊聊，让想法慢慢成形 / C看当天的情境，再决定怎么准备 / A留点不被打扰的时间，做自己的事 / 约熟悉的人见面，随意走一走已选择 / C暂时不安排，到时候再看看 / A先写下几个要点，想清楚再表达 / 先找一个人聊聊，让想法慢慢成形已选择：校验optionId且非completed；克隆后persist；失败保留pendingAnswer，下一题被阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- retry-save · 重试保存：关闭save-failure模拟开关，重用pendingAnswer写入；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- rescue · 导出临时答案：浏览器下载临时pending答案+session的明文JSON；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- confirm-dialog · 保存位置，返回认识：调用当前dialogCallback；submit先trim且不能为空；confirm先关闭再执行；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- close-dialog · 先取消：关闭弹层、解除inert/滚动锁、回焦点；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- answer.persist [local] 选项变化且校验通过。请求：sessionId,questionId,optionId,revision,contentVersion；返回：持久化成功revision或失败
- 本地 答卷：现有 id,kind,version,mode,status,index,answers{questionId:optionId},createdAt,updatedAt,updatedLabel,activeSession；计划 spaceId/sessionId/assessmentId/contentVersion/scoringVersion/answerRevision/saveState/submitToken/resultId?；本机个人空间；完成后只读快照；保留时长与清理策略待D-08，云副本不是默认
- 本地 题库/阅读/专题包：现有 D.questions{3个原创questionId,title,options}；D.topics{5个topicId,category,prompts}；D.report；D.factors；均随JS静态提供；计划 packId/contentVersion/assessmentId/questionId/optionId/licenseEvidence/eligibilityStatus/scoringVersion/normVersion/checksum；全部发布题库默认随安装本地；首启不依赖下载。资格不成立不分发正式内容；更新/撤回保留旧任务版本。更新服务如启用仅请求包和版本元数据
- 本地 编辑草稿/未保存选择：现有 editorDrafts{journal:id,topic:topicId:id,report:context,action-review:id}；pendingAnswer内存；V2.cachedDrafts/failedDrafts内存；计划 draftId/ownerSpaceId/objectId/baseRevision/updatedAt/saveStatus；本机；失败不清输入，迁移需独立预检；原型LocalStorage明文并非APP方案
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 待修/待验：已完成答卷深链到question仍展示可点击选项样式；answer handler拒绝写入，但视觉/可用态不一致，待修
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-006, ZY-FR-007, ZY-FR-008, ZY-FR-005, ZY-NFR-014, ZY-DATA-004, ZY-ENG-001
- 验收ID：T-FR-006-N, T-FR-006-E1, T-FR-006-E2, T-FR-006-E3, T-FR-007-N, T-FR-007-E1, T-FR-007-E2, T-FR-007-E3, T-FR-008-N, T-FR-008-E1, T-FR-008-E2, T-FR-008-E3, T-FR-005-N, T-FR-005-E1, T-FR-005-E2, T-FR-005-E3, T-NFR-014-N, T-DATA-004, T-ENG-001
- 待决：D-02 16PF题源与授权（产品负责人，必要时由测量/法律/工程专业方协助）；D-03 AI重置版身份（产品负责人，必要时由测量/法律/工程专业方协助）；D-04 计分常模与适用性（产品负责人，必要时由测量/法律/工程专业方协助）；D-05 首版完整价值切片（产品负责人，必要时由测量/法律/工程专业方协助）；D-08 空间、留存与备份（产品负责人，必要时由测量/法律/工程专业方协助）；D-11 平台与发布顺序（产品负责人，必要时由测量/法律/工程专业方协助）；D-14 设备与质量目标（产品负责人，必要时由测量/法律/工程专业方协助）；PAGE-ARCH-CANDIDATE 本地计算/本地报告/会员云保存（产品负责人和客户端/服务端工程，专业与隐私审校按需参与）

## 作答检查 · review

- 主线：答案核对→提交固定结果
- 最小价值：检查漏题、修改未完成答卷、完成一次任务
- 前置：原session存在；完整性和原版本门禁成立
- 出入与返回：question末题→review；修改回指定题；完成→complete；回看样例→report
- 当前边界：当前finish只标completed；未计分、未创建正式result；计算位置待架构定案
- 实际/计划状态：有漏题, 完整未提交, 已完成只读, 对象缺失

### 按钮与事件

- back · 返回：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 回到列表：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- edit-answer · 修改：仅未completed session可改index并回question；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- finish · 完成答题体验：答案3项才标completed并转complete；无计分、无真实result；当前真实出网=无；计划位置=undecided；同名操作语义保留；正式实现尚未接入/验证
- nav · 看看独立报告样例：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- result.commit [undecided] 确认完成且题库/完整性/质量门禁通过。请求：sessionId,answersRevision,content/scoring/normVersions,submitToken；返回：确定性resultId/报告状态；本地计算/本地报告候选待后续架构定案
- 本地 答卷：现有 id,kind,version,mode,status,index,answers{questionId:optionId},createdAt,updatedAt,updatedLabel,activeSession；计划 spaceId/sessionId/assessmentId/contentVersion/scoringVersion/answerRevision/saveState/submitToken/resultId?；本机个人空间；完成后只读快照；保留时长与清理策略待D-08，云副本不是默认
- 本地 题库/阅读/专题包：现有 D.questions{3个原创questionId,title,options}；D.topics{5个topicId,category,prompts}；D.report；D.factors；均随JS静态提供；计划 packId/contentVersion/assessmentId/questionId/optionId/licenseEvidence/eligibilityStatus/scoringVersion/normVersion/checksum；全部发布题库默认随安装本地；首启不依赖下载。资格不成立不分发正式内容；更新/撤回保留旧任务版本。更新服务如启用仅请求包和版本元数据
- 本地 正式结果/报告：现有 当前仅独立report-sample-01与示意factor值；不存在真实result对象；计划 resultId/sessionId/reportVersion/contentVersion/scoringVersion/normVersion/factorValues/unknownFlags/qualityFlag/interpretationEvidence；本地计算、本地报告均候选未决；必须确定性可复现。若决定会员云保存，另定授权范围/留存/删除，不默认上传答案
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-008, ZY-FR-006, ZY-MEAS-004, ZY-MEAS-005, ZY-NFR-009
- 验收ID：T-FR-008-N, T-FR-008-E1, T-FR-008-E2, T-FR-008-E3, T-FR-006-N, T-FR-006-E1, T-FR-006-E2, T-FR-006-E3, T-MEAS-004, T-MEAS-005, T-NFR-009-N
- 待决：D-02 16PF题源与授权（产品负责人，必要时由测量/法律/工程专业方协助）；D-03 AI重置版身份（产品负责人，必要时由测量/法律/工程专业方协助）；D-04 计分常模与适用性（产品负责人，必要时由测量/法律/工程专业方协助）；PAGE-ARCH-CANDIDATE 本地计算/本地报告/会员云保存（产品负责人和客户端/服务端工程，专业与隐私审校按需参与）

## 完成回执 · complete

- 主线：提交→可信回执→结果阅读
- 最小价值：确认本次答卷确实留存，决定下一步
- 前置：指定session已completed；否则不可展示完成
- 出入与返回：review→complete?id；report样例或home；返回不重复提交
- 当前边界：仅回执3题演示，报告是独立虚构样例，不是本次计算产物
- 实际/计划状态：成功, 未完成, 不存在

### 按钮与事件

- back · 返回 / 回到认识：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 回到列表：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 查看独立报告样例：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 回到认识：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- complete.local-interaction [local] 页面进入、输入或本人点击本页现有操作。请求：本页明确对象ID/版本及必要字段；返回：本机内容或保存/恢复状态
- 本地 答卷：现有 id,kind,version,mode,status,index,answers{questionId:optionId},createdAt,updatedAt,updatedLabel,activeSession；计划 spaceId/sessionId/assessmentId/contentVersion/scoringVersion/answerRevision/saveState/submitToken/resultId?；本机个人空间；完成后只读快照；保留时长与清理策略待D-08，云副本不是默认
- 本地 正式结果/报告：现有 当前仅独立report-sample-01与示意factor值；不存在真实result对象；计划 resultId/sessionId/reportVersion/contentVersion/scoringVersion/normVersion/factorValues/unknownFlags/qualityFlag/interpretationEvidence；本地计算、本地报告均候选未决；必须确定性可复现。若决定会员云保存，另定授权范围/留存/删除，不默认上传答案
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-008, ZY-FR-009, ZY-NFR-017
- 验收ID：T-FR-008-N, T-FR-008-E1, T-FR-008-E2, T-FR-008-E3, T-FR-009-N, T-FR-009-E1, T-FR-009-E2, T-NFR-017-N
- 待决：D-02 16PF题源与授权（产品负责人，必要时由测量/法律/工程专业方协助）；D-03 AI重置版身份（产品负责人，必要时由测量/法律/工程专业方协助）；D-04 计分常模与适用性（产品负责人，必要时由测量/法律/工程专业方协助）；D-05 首版完整价值切片（产品负责人，必要时由测量/法律/工程专业方协助）；PAGE-ARCH-CANDIDATE 本地计算/本地报告/会员云保存（产品负责人和客户端/服务端工程，专业与隐私审校按需参与）

## 报告阅读 · report

- 主线：依据→本人补充→可选尝试/AI
- 最小价值：读懂来源和限制，保留自己的不同经历
- 前置：当前仅report-sample-01；正式报告须有可追溯版本与资格
- 出入与返回：records/complete→report?id；share；引用→assistant；尝试→action-detail
- 当前边界：正式报告、本地计算和本地生成均未实现；候选架构不应在页级契约偷偷定案
- 实际/计划状态：工作, 相处情境, 因子未知, 本人草稿, 保存失败, 对象缺失

### 按钮与事件

- back · 返回：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 选择分享范围：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- report-jump · 要点 / 依据 / 我的观察 / 下一步 / 这些解读从哪里来：定位section，focus+scroll，减少动态时instant；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- report-context · 工作 / 相处：本机reportContext切换work/relationship；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- source-report · 核对来源与版本：打开样例来源或当前消息保存的source快照；显示旧来源失效标记；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- factor · A 乐群，位置仅为示意，查看说明 / B 推理，暂无依据，查看说明 / C 情绪稳定，位置仅为示意，查看说明 / E 支配，位置仅为示意，查看说明 / F 活泼，位置仅为示意，查看说明 / G 规则意识，位置仅为示意，查看说明 / H 社交大胆，位置仅为示意，查看说明 / I 敏感，位置仅为示意，查看说明 / L 警觉，位置仅为示意，查看说明 / M 抽象，位置仅为示意，查看说明 / N 私密，位置仅为示意，查看说明 / O 忧虑，暂无依据，查看说明 / Q1 开放变化，位置仅为示意，查看说明 / Q2 自立，位置仅为示意，查看说明 / Q3 自律，位置仅为示意，查看说明 / Q4 紧张，位置仅为示意，查看说明：若sim-factors选模式则更新内存simFactor；否则展示该因子样例/未知与边界；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- save-report-note · 保存本人观察：V2取report:context草稿；非空新建本人note，清草稿；不改报告；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- add-action · 留下这个小尝试：V2生成可改表单；专题需已保存版本；同文字同来源revision且active时复用；保存后action-detail；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- quote-report · 带着样例情境问助理：V2.attachSource去重/更新来源版本并填默认草稿→assistant；topic脏草稿须选已存版；文章固定quote-1非真实选段；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 查看已保存的观察：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- factor-sim · 用这个角度做个假设：内存simFactor=id，跳旧simulation；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- close-dialog · 回到刚才的位置：关闭弹层、解除inert/滚动锁、回焦点；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- submit-dialog · 保存到本机：调用当前dialogCallback；submit先trim且不能为空；confirm先关闭再执行；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- report.read [undecided] 本人打开指定正式报告。请求：resultId,reportVersion,ownerSpaceId；返回：该版本报告；本地生成/本地缓存/云取策略未定
- analysis.submit [cloud] 本人主动分析且AI额度与引用同意通过。请求：logicalRequestId,明确选定报告片段/自述；返回：AI分析结果独立于确定性分数；共享10/日
- 本地 正式结果/报告：现有 当前仅独立report-sample-01与示意factor值；不存在真实result对象；计划 resultId/sessionId/reportVersion/contentVersion/scoringVersion/normVersion/factorValues/unknownFlags/qualityFlag/interpretationEvidence；本地计算、本地报告均候选未决；必须确定性可复现。若决定会员云保存，另定授权范围/留存/删除，不默认上传答案
- 本地 本次引用/来源快照：现有 id,kind,objectId,version,sectionId,title,excerpt,status,scope；计划 ownerSpaceId/sourceRef/objectRevision/selectedScope/executedSnapshot/revocationState；草稿引用可移除；正式发送先校验来源与版本；历史执行快照和当前可用状态分开；不自动读取全部历史
- 本地 本人观察与专题整理：现有 id,kind,topicId,title,fields,text,revision,revisions{revision,fields,text,createdAt},sourceId,sourceKind,sectionId,createdAt,updatedAt；计划 ownerSpaceId/recordId/sourceRefs/currentRevision/explicitConsent；自述与测量事实分别标识；本人本机；历史修订保留；删除同时处理草稿与关联来源全文，已导出副本不可撤回
- 本地 编辑草稿/未保存选择：现有 editorDrafts{journal:id,topic:topicId:id,report:context,action-review:id}；pendingAnswer内存；V2.cachedDrafts/failedDrafts内存；计划 draftId/ownerSpaceId/objectId/baseRevision/updatedAt/saveStatus；本机；失败不清输入，迁移需独立预检；原型LocalStorage明文并非APP方案
- 本地 小尝试与实际回看：现有 id,text,revision,status,sourceId,sourceKind,sourceVersion,sourceSnapshot,sectionId,reviews{id,outcome,text,actionText,actionRevision,createdAt},createdAt；计划 spaceId/actionId/reviewId/sourceRevision/reviewSubmitToken；本机本人决定；计划与实际观察独立；修改计划不改历史回看；提醒额外授权后才启用
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-009, ZY-FR-010, ZY-FR-019, ZY-FR-025, ZY-MEAS-007, ZY-MEAS-008
- 验收ID：T-FR-009-N, T-FR-009-E1, T-FR-009-E2, T-FR-010-N, T-FR-010-E1, T-FR-010-E2, T-FR-019-N, T-FR-019-E1, T-FR-019-E2, T-FR-025-N, T-FR-025-E1, T-FR-025-E2, T-FR-025-E3, T-MEAS-007, T-LEG-12, T-MEAS-008
- 待决：D-02 16PF题源与授权（产品负责人，必要时由测量/法律/工程专业方协助）；D-03 AI重置版身份（产品负责人，必要时由测量/法律/工程专业方协助）；D-04 计分常模与适用性（产品负责人，必要时由测量/法律/工程专业方协助）；D-05 首版完整价值切片（产品负责人，必要时由测量/法律/工程专业方协助）；D-06 AI供应商与数据用途（产品负责人，必要时由测量/法律/工程专业方协助）；D-07 共享次数与计量（产品负责人，必要时由测量/法律/工程专业方协助）；D-16 内容与支持运营（产品负责人，必要时由测量/法律/工程专业方协助）；PAGE-ARCH-CANDIDATE 本地计算/本地报告/会员云保存（产品负责人和客户端/服务端工程，专业与隐私审校按需参与）

## 测评与记录 · records

- 主线：本人资料找回→原对象
- 最小价值：按类型找回答卷、本人观察与报告补充
- 前置：当前空间可读；不要求登录
- 出入与返回：me分类入口；每项以原id和topic打开；返回原筛选/位置
- 当前边界：当前无全文检索和完整时间线；不能以列表存在声称跨类别搜索已实现
- 实际/计划状态：空, 按类无记录, 本人记录, 全部答卷, 未完成, 完整

### 按钮与事件

- back · 我的：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 写观察 / 写一个观察 / 本人观察虚构记录审计用虚构观察10月1日 · 本机 / 报告补充报告补充审计用虚构补充10月1日 · 本机：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- record-filter · 全部 / 本人记录 / 全部答卷 / 本人观察 / 报告补充 / 未完成 / 体验答卷：更新本机筛选状态并重绘；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 查看我的小尝试计划与实际结果：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 两份结果的可比性核对来源和量纲后再比较：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 专题整理工作选择 · 整理审计用虚构整理10月1日 · 本机：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 未完成3 道交互示例题已保存 3 / 3 题10月1日 · 本机：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- records.local-interaction [local] 页面进入、输入或本人点击本页现有操作。请求：本页明确对象ID/版本及必要字段；返回：本机内容或保存/恢复状态
- 本地 答卷：现有 id,kind,version,mode,status,index,answers{questionId:optionId},createdAt,updatedAt,updatedLabel,activeSession；计划 spaceId/sessionId/assessmentId/contentVersion/scoringVersion/answerRevision/saveState/submitToken/resultId?；本机个人空间；完成后只读快照；保留时长与清理策略待D-08，云副本不是默认
- 本地 本人观察与专题整理：现有 id,kind,topicId,title,fields,text,revision,revisions{revision,fields,text,createdAt},sourceId,sourceKind,sectionId,createdAt,updatedAt；计划 ownerSpaceId/recordId/sourceRefs/currentRevision/explicitConsent；自述与测量事实分别标识；本人本机；历史修订保留；删除同时处理草稿与关联来源全文，已导出副本不可撤回
- 本地 页面上下文：现有 route,params{id,topic,kind,tab},stack,scrolls,recordFilter,exploreCategory,exploreSearch,returnAfterAuth,checkoutReturn；计划 route/objectId/returnIntent/scrollAnchor；正文不进URL；本机UI上下文；内存与偏好保存边界由工程定；不需云端
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-011, ZY-FR-007, ZY-FR-055, ZY-DATA-003
- 验收ID：T-FR-011-N, T-FR-011-E1, T-FR-011-E2, T-FR-007-N, T-FR-007-E1, T-FR-007-E2, T-FR-007-E3, T-FR-055-N, T-FR-055-E1, T-FR-055-E2, T-FR-055-E3, T-DATA-003, T-DATA-003-R3-INTERRUPT, T-DATA-003-R3-SWITCH
- 待决：D-05 首版完整价值切片（产品负责人，必要时由测量/法律/工程专业方协助）；D-08 空间、留存与备份（产品负责人，必要时由测量/法律/工程专业方协助）

## 专题介绍 · topic

- 主线：现实议题→自助整理
- 最小价值：了解专题用途、问题与产出，再开始
- 前置：5个topicId之一；无账号门槛
- 出入与返回：explore→topic?id；开始/继续→topic-workspace?topic&id；返回explore
- 当前边界：固定自助框架不预测职业城市关系结果；页面标原3–4核心问题，实际编辑含新增反思项6–7字段
- 实际/计划状态：未收藏, 已收藏, 无记录, 有同专题旧记录, 未知topic

### 按钮与事件

- back · 探索：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- favorite · 收藏这个主题：本机favorites按topicId添加/移除；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- topic-journal · 开始整理 / 另建一份整理：V2覆盖旧跳转，实际→topic-workspace?topic=id；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 继续上次的整理：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- topic.local-interaction [local] 页面进入、输入或本人点击本页现有操作。请求：本页明确对象ID/版本及必要字段；返回：本机内容或保存/恢复状态
- 本地 题库/阅读/专题包：现有 D.questions{3个原创questionId,title,options}；D.topics{5个topicId,category,prompts}；D.report；D.factors；均随JS静态提供；计划 packId/contentVersion/assessmentId/questionId/optionId/licenseEvidence/eligibilityStatus/scoringVersion/normVersion/checksum；全部发布题库默认随安装本地；首启不依赖下载。资格不成立不分发正式内容；更新/撤回保留旧任务版本。更新服务如启用仅请求包和版本元数据
- 本地 专题收藏：现有 favorites[topicId]；计划 spaceId/topicId/savedAt/contentVersion?；当前本机；不需云；跨端同步候选未定
- 本地 本人观察与专题整理：现有 id,kind,topicId,title,fields,text,revision,revisions{revision,fields,text,createdAt},sourceId,sourceKind,sectionId,createdAt,updatedAt；计划 ownerSpaceId/recordId/sourceRefs/currentRevision/explicitConsent；自述与测量事实分别标识；本人本机；历史修订保留；删除同时处理草稿与关联来源全文，已导出副本不可撤回
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-003, ZY-FR-004, ZY-FR-017, ZY-LIFE-006
- 验收ID：T-FR-003-N, T-FR-003-E1, T-FR-003-E2, T-FR-004-N, T-FR-004-E1, T-FR-004-E2, T-FR-017-N, T-FR-017-E1, T-FR-017-E2, T-LIFE-006, T-LEG-01
- 待决：D-01 目标人群与边界（产品负责人，必要时由测量/法律/工程专业方协助）；D-02 16PF题源与授权（产品负责人，必要时由测量/法律/工程专业方协助）；D-03 AI重置版身份（产品负责人，必要时由测量/法律/工程专业方协助）；D-04 计分常模与适用性（产品负责人，必要时由测量/法律/工程专业方协助）；D-05 首版完整价值切片（产品负责人，必要时由测量/法律/工程专业方协助）

## 主题与形象 · appearance

- 主线：个人偏好→一致阅读体验
- 最小价值：独立选择主题、人物、密度和动效
- 前置：本机设置；无账号无系统权限
- 出入与返回：settings/原入口→appearance；返回原任务，选择互不覆盖
- 当前边界：完整捏脸未实现；主题候选最终发行集合待定
- 实际/计划状态：8原始, 4历史候选, 6人物, 舒展紧凑, 减少动态

### 按钮与事件

- back · 返回：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- theme · 晨光奶油珊瑚橙 · 蜜桃 · 暖金 / 糖霜星云玫粉 · 杏橘 · 糖霜黄 / 莓果汽泡莓粉 · 葡萄紫 · 冰蓝 / 青柠薄雾青柠绿 · 翠绿 · 透青 / 流光天幕晴空蓝 · 轻紫 · 晚霞粉 / 海盐晴蓝晴蓝 · 海青 · 薄绿 / 夜航星云深夜蓝 · 星紫 · 冷光青 / 琥珀潮汐深梅色 · 赭橙 · 流金 / 青屿晨光保留 V1/V2 · 叶绿与浅杏 / 杏桃晚风保留 V1/V2 · 杏桃与茶褐 / 海盐晴空保留 V1/V2 · 雾蓝与云白 / 灵感紫保留 V3 · 鸢尾与淡紫：校验允许枚举后写本机偏好并局部刷新；人物family与theme分开；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- v3-density · 舒展留一点呼吸 / 紧凑一眼多看一点：校验允许枚举后写本机偏好并局部刷新；人物family与theme分开；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- toggle-motion · 减少动态：校验允许枚举后写本机偏好并局部刷新；人物family与theme分开；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- avatar · 人物 01 / 人物 02 / 人物 03 / 场景 01 / 场景 02 / 场景 03：校验允许枚举后写本机偏好并局部刷新；人物family与theme分开；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- appearance.local-interaction [local] 页面进入、输入或本人点击本页现有操作。请求：本页明确对象ID/版本及必要字段；返回：本机内容或保存/恢复状态
- 本地 展示与隐私偏好：现有 name,avatar,avatarFamily,theme,density,fontSize,reduced,workspaceMode,chatRetention,memoryEnabled；不含真实画像；计划 settingsVersion/ownerScope/accessibilityOverrides/consentVersions；与推断画像分离；本机展示偏好；云同步若选用须明确字段；关闭留存只作用后续会话，不伪称删历史
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-040, ZY-FR-041, ZY-FR-042, ZY-UX-003, ZY-UX-004
- 验收ID：T-FR-040-N, T-FR-040-E1, T-FR-040-E2, T-FR-041-N, T-FR-041-E1, T-FR-041-E2, T-FR-042-N, T-FR-042-E1, T-FR-042-E2, T-UX-003, T-UX-004
- 待决：D-12 视觉与资产定稿（产品负责人，必要时由测量/法律/工程专业方协助）；D-14 设备与质量目标（产品负责人，必要时由测量/法律/工程专业方协助）

## 对话历史 · conversations

- 主线：找回原会话→续聊
- 最小价值：打开同一会话，不重新生成
- 前置：当前空间历史；正式云历史范围未定
- 出入与返回：assistant→conversations；conversation?id；新话题assistant
- 当前边界：打开历史不计次；不自动把所有历史外发
- 实际/计划状态：空, 有历史, 对象已删除

### 按钮与事件

- back · 助理：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 新话题 / 准备一个问题：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 虚构对话本机演示 · 2 条消息：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- conversations.local-interaction [local] 页面进入、输入或本人点击本页现有操作。请求：本页明确对象ID/版本及必要字段；返回：本机内容或保存/恢复状态
- 本地 对话与AI请求：现有 assistantDraft,assistantSources；conversations{id,title,persist,draft,draftSources,messages,generating,requestId,pendingRequest,interrupted,updatedLabel}；message{id,role,text,sources,requestId,createdAt,status}；计划 accountId/spaceId/conversationId/messageId/logicalRequestId/operationKind/sourceSnapshotId/status/sequence/retentionScope；草稿本机；非留存对话仅内存。真实AI外发所选正文至明确供应方/云服务；服务端与供应商留存期D-06/08未定，不能承诺零留存
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-021, ZY-FR-020, ZY-DATA-003
- 验收ID：T-FR-021-N, T-FR-021-E1, T-FR-021-E2, T-FR-020-N, T-FR-020-E1, T-FR-020-E2, T-FR-020-E3, T-DATA-003, T-DATA-003-R3-INTERRUPT, T-DATA-003-R3-SWITCH
- 待决：D-06 AI供应商与数据用途（产品负责人，必要时由测量/法律/工程专业方协助）；D-07 共享次数与计量（产品负责人，必要时由测量/法律/工程专业方协助）；D-08 空间、留存与备份（产品负责人，必要时由测量/法律/工程专业方协助）

## 连续对话 · conversation

- 主线：AI任务→可追溯回答→用户反馈/记忆/行动
- 最小价值：续聊、停止、核对来源、选择是否采用
- 前置：会话ID与发起账号一致；发送须登录和额度；来源版本仍有效
- 出入与返回：assistant发送→conversation?id；来源弹层；小尝试action-detail；删除回conversations
- 当前边界：当前650ms计时器预写回复；不是流式AI；纠正只说明并由用户后续输入，不具反馈闭环
- 实际/计划状态：预写返回, 生成中, 停止, 窗口中断, 非留存, 来源失效, 缺失会话

### 按钮与事件

- back · 返回 / 返回对话：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 回到列表：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- conversation-settings · 这段对话的设置：显示persist和对象ID；删除入口与privacy入口；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- message-source · 参考：独立报告样例 · 工作情境 · 查看当时片段：打开样例来源或当前消息保存的source快照；显示旧来源失效标记；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- add-action · 留一个小尝试：V2生成可改表单；专题需已保存版本；同文字同来源revision且active时复用；保存后action-detail；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- candidate-memory · 提出一条记忆候选：V2拦样例；App校memoryEnabled与来源有效，用户编辑后存candidate，不自动active；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- correct-response · 不太符合：不太符合仅打开解释，要求在输入框补充；未结构化关联纠错；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- remove-source · 移除本次引用：从assistantSources或conversation.draftSources移除；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- context · 已选 1 份资料：V2列最近本人记录/确认记忆；样例在独立details，选择不自动发送；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- send · 发送演示：空文阻止；访客→auth保留returnAfterAuth；用尽保留草稿；生成中拒绝重复；引用有效后本机存消息+used++；650ms回预写文本；当前真实出网=无；计划位置=cloud；同名操作语义保留；正式实现尚未接入/验证
- stop · 停止：clearTimeout并置generating=false；演示计数保留；不自动重发；当前真实出网=无；计划位置=cloud；同名操作语义保留；正式实现尚未接入/验证
- delete-conversation · 删除本机这段对话：确认后删本机会话，关联memory停用，取消timer，回列表；当前真实出网=无；计划位置=undecided；同名操作语义保留；正式实现尚未接入/验证
- nav · 查看引用与留存设置：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- submit-dialog · 保存到本机：调用当前dialogCallback；submit先trim且不能为空；confirm先关闭再执行；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- submit-dialog · 保存到本机：调用当前dialogCallback；submit先trim且不能为空；confirm先关闭再执行；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 写一条本人观察：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 查看引用与记忆设置：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- close-dialog · 保留对话，不建立记忆 / 先不记住：关闭弹层、解除inert/滚动锁、回焦点；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- v2-pick-context · 选择具体本人记录/已确认记忆/独立样例：校验选中source有效，加入当前草稿，关闭弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- close-dialog · 取消选择：关闭弹层、解除inert/滚动锁、回焦点；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- close-dialog · 保留草稿，继续看看：关闭弹层、解除inert/滚动锁、回焦点；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 了解使用与会员规则：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- confirm-dialog · 删除本机对话：调用当前dialogCallback；submit先trim且不能为空；confirm先关闭再执行；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- ai.request.resume [cloud] 重连/回到原任务，仅重取同request。请求：accountId,requestId,lastSequence；返回：同任务状态或已存结果，不新扣次
- ai.request.cancel [cloud] 本人停止。请求：requestId；返回：取消状态、晚到结果及计量状态
- 本地 对话与AI请求：现有 assistantDraft,assistantSources；conversations{id,title,persist,draft,draftSources,messages,generating,requestId,pendingRequest,interrupted,updatedLabel}；message{id,role,text,sources,requestId,createdAt,status}；计划 accountId/spaceId/conversationId/messageId/logicalRequestId/operationKind/sourceSnapshotId/status/sequence/retentionScope；草稿本机；非留存对话仅内存。真实AI外发所选正文至明确供应方/云服务；服务端与供应商留存期D-06/08未定，不能承诺零留存
- 本地 本次引用/来源快照：现有 id,kind,objectId,version,sectionId,title,excerpt,status,scope；计划 ownerSpaceId/sourceRef/objectRevision/selectedScope/executedSnapshot/revocationState；草稿引用可移除；正式发送先校验来源与版本；历史执行快照和当前可用状态分开；不自动读取全部历史
- 本地 AI用量账本：现有 used,usageDay,usage{id,kind,status,createdAt}；全部本机演示可绕过；计划 accountId/dayKey/logicalRequestId/kind/settlementState/quotaPolicyVersion/used/remaining；真实额度云端按账号跨设备统一；访客0，登录非会员分析+chat合计10/日；升级、到期、退款不重置已用量；日界线和失败/停止结算D-07未决
- 本地 长期记忆：现有 id,text,status(candidate/active/inactive),revision,sourceId,sourceMessageId,sourceType,sourceTitle；计划 memoryId/ownerSpaceId/sourceRevision/confirmedAt/validity/revocationRevision；逐条本人确认；修订回候选；停用阻断新检索与在途采用。云检索如启用需副本/索引删除传播，当前无此实现
- 本地 小尝试与实际回看：现有 id,text,revision,status,sourceId,sourceKind,sourceVersion,sourceSnapshot,sectionId,reviews{id,outcome,text,actionText,actionRevision,createdAt},createdAt；计划 spaceId/actionId/reviewId/sourceRevision/reviewSubmitToken；本机本人决定；计划与实际观察独立；修改计划不改历史回看；提醒额外授权后才启用
- 本地 编辑草稿/未保存选择：现有 editorDrafts{journal:id,topic:topicId:id,report:context,action-review:id}；pendingAnswer内存；V2.cachedDrafts/failedDrafts内存；计划 draftId/ownerSpaceId/objectId/baseRevision/updatedAt/saveStatus；本机；失败不清输入，迁移需独立预检；原型LocalStorage明文并非APP方案
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-020, ZY-FR-021, ZY-FR-022, ZY-FR-023, ZY-FR-028, ZY-AI-001, ZY-AI-002, ZY-AI-004
- 验收ID：T-FR-020-N, T-FR-020-E1, T-FR-020-E2, T-FR-020-E3, T-FR-021-N, T-FR-021-E1, T-FR-021-E2, T-FR-022-N, T-FR-022-E1, T-FR-022-E2, T-FR-022-E3, T-FR-023-N, T-FR-023-E1, T-FR-023-E2, T-FR-023-E3, T-FR-023-R2-SHARED, T-FR-023-R3-DAILYAI-1, T-FR-023-R3-DAILYAI-2, T-FR-023-R3-DAILYAI-3, T-FR-023-R3-DAILYAI-4, T-FR-028-N, T-FR-028-E1, T-FR-028-E2, T-FR-028-E3, T-AI-001, T-AI-002, T-AI-004, T-AI-004-R3-KEY, T-AI-004-R3-DAY
- 待决：D-06 AI供应商与数据用途（产品负责人，必要时由测量/法律/工程专业方协助）；D-07 共享次数与计量（产品负责人，必要时由测量/法律/工程专业方协助）；D-08 空间、留存与备份（产品负责人，必要时由测量/法律/工程专业方协助）；D-13 安全与专业审校（产品负责人，必要时由测量/法律/工程专业方协助）；D-14 设备与质量目标（产品负责人，必要时由测量/法律/工程专业方协助）；D-17 每日选题与画像更新策略（产品负责人，必要时由测量/内容/工程专业方协助）；D-21 账号关联与防重复领额度（产品负责人，开发接入时与工程核验）

## 登录与注册 · auth

- 主线：AI入口受控→身份验证→返回原草稿
- 最小价值：证明账号身份并继续原任务
- 前置：真实流程需平台授权/短信服务与协议；本机资料不自动认领
- 出入与返回：AI前置/我的→auth；演示登录returnAfterAuth；取消返回原页
- 当前边界：当前只有auth-spec/demo-login/back；微信/支付宝优先、首次无关联建号、短信绑手机与手机号备选仅需求记录
- 实际/计划状态：演示说明, 正式未接入；计划需授权取消、验证码错误, 过期、限频、冲突

### 按钮与事件

- back · 暂不登录 / 保留草稿，暂不登录：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- auth-spec · 创建账号的正式流程用途说明 → 本人同意 → 身份验证 → 回原草稿查看：真实认证流程说明，旧文本尚未完整反映微信/支付宝优先和短信绑定；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- demo-login · 使用演示账号继续：只设logged=true并回returnAfterAuth；不创建账号不上传草稿；当前真实出网=无；计划位置=local；演示专用：不得进入正式APP；正式业务另见page.plannedOperations

### API与数据

- identity.provider.verify [cloud] 微信/支付宝正式入口（待设计）→授权返回时。请求：provider,授权证明,authFlowId,state/nonce,consentVersion；返回：账号ID/关联状态/会话/下一步；取消不建号
- identity.sms.verify [cloud] 手机备选登录或绑定时。请求：phone,一次性验证证明,用途,challengeId；不永久保留明文验证码；返回：验证/限频/关联冲突结果
- identity.space.claim [undecided] 验证后本人明确选择沿用本机资料时。请求：spaceId,accountId,认领选择,范围（不默认上传正文）；返回：归属变更/保留访客/冲突；上传是另一个同意
- 本地 身份/关联/会话：现有 仅logged布尔，无密码验证码和真实账号；计划 accountId/providerSubject映射/verifiedPhone关联/sessionStatus/consentVersion/spaceClaimChoice/abuseEvidence最小集；认证与共享额度必须云权威；验证码不明文留存；令牌安全系统存储方案待定；本机资料认领不等于云上传
- 本地 页面上下文：现有 route,params{id,topic,kind,tab},stack,scrolls,recordFilter,exploreCategory,exploreSearch,returnAfterAuth,checkoutReturn；计划 route/objectId/returnIntent/scrollAnchor；正文不进URL；本机UI上下文；内存与偏好保存边界由工程定；不需云端
- 本地 编辑草稿/未保存选择：现有 editorDrafts{journal:id,topic:topicId:id,report:context,action-review:id}；pendingAnswer内存；V2.cachedDrafts/failedDrafts内存；计划 draftId/ownerSpaceId/objectId/baseRevision/updatedAt/saveStatus；本机；失败不清输入，迁移需独立预检；原型LocalStorage明文并非APP方案
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-037, ZY-FR-038, ZY-FR-023, ZY-BR-001, ZY-DATA-003, ZY-ENG-009
- 验收ID：T-FR-037-N, T-FR-037-E1, T-FR-037-E2, T-FR-037-E3, T-FR-037-R2-AUTH, T-FR-037-R2-SMS, T-FR-037-R2-CANCEL, T-FR-037-R3-STATE-1, T-FR-037-R3-STATE-2, T-FR-037-R3-STATE-3, T-FR-037-R3-CONFLICT-1, T-FR-037-R3-CONFLICT-2, T-FR-038-N, T-FR-038-E1, T-FR-038-E2, T-FR-038-E3, T-FR-038-R2-LIFECYCLE, T-FR-038-R3-RECOVERY-1, T-FR-038-R3-RECOVERY-2, T-FR-038-R3-RECOVERY-3, T-FR-023-N, T-FR-023-E1, T-FR-023-E2, T-FR-023-E3, T-FR-023-R2-SHARED, T-FR-023-R3-DAILYAI-1, T-FR-023-R3-DAILYAI-2, T-FR-023-R3-DAILYAI-3, T-FR-023-R3-DAILYAI-4, T-BR-001-N, T-BR-001-R2-LINK, T-BR-001-R3-STALE, T-BR-001-R3-RACE, T-DATA-003, T-DATA-003-R3-INTERRUPT, T-DATA-003-R3-SWITCH, T-ENG-009, T-LEG-04
- 待决：D-06 AI供应商与数据用途（产品负责人，必要时由测量/法律/工程专业方协助）；D-07 共享次数与计量（产品负责人，必要时由测量/法律/工程专业方协助）；D-08 空间、留存与备份（产品负责人，必要时由测量/法律/工程专业方协助）；D-11 平台与发布顺序（产品负责人，必要时由测量/法律/工程专业方协助）；D-16 内容与支持运营（产品负责人，必要时由测量/法律/工程专业方协助）；D-17 每日选题与画像更新策略（产品负责人，必要时由测量/内容/工程专业方协助）；D-20 手机号绑定强制时机（产品负责人，开发接入时与工程核验）；D-21 账号关联与防重复领额度（产品负责人，开发接入时与工程核验）

## 助理记忆 · memories

- 主线：候选→确认→修订/停用/删除
- 最小价值：本人控制长期采用的认识
- 前置：需真实来源；样例和假设不能升级本人记忆
- 出入与返回：me/assistant/privacy→memories；引用设置privacy；返回原位置
- 当前边界：原型仅本机；服务端检索、摘要、在途任务撤回传播未实现
- 实际/计划状态：空, 候选, 生效, 停用, 来源失效

### 按钮与事件

- back · 我的：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 引用设置：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 回到助理：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- confirm-memory · 确认采用：仅candidate改active；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- edit-memory · 修改：编辑后revision++且回candidate；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- delete-memory · 删除：确认后删本机memory并移出草稿；历史消息快照保留；当前真实出网=无；计划位置=undecided；同名操作语义保留；正式实现尚未接入/验证
- deactivate-memory · 停止使用：改inactive，移出所有未发送draft引用；当前真实出网=无；计划位置=undecided；同名操作语义保留；正式实现尚未接入/验证
- inactive-info · 查看停用说明：已停用记忆影响范围说明，未执行云传播；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- submit-dialog · 保存到本机：调用当前dialogCallback；submit先trim且不能为空；confirm先关闭再执行；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- confirm-dialog · 删除本机记忆：调用当前dialogCallback；submit先trim且不能为空；confirm先关闭再执行；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- memories.local-interaction [local] 页面进入、输入或本人点击本页现有操作。请求：本页明确对象ID/版本及必要字段；返回：本机内容或保存/恢复状态
- 本地 长期记忆：现有 id,text,status(candidate/active/inactive),revision,sourceId,sourceMessageId,sourceType,sourceTitle；计划 memoryId/ownerSpaceId/sourceRevision/confirmedAt/validity/revocationRevision；逐条本人确认；修订回候选；停用阻断新检索与在途采用。云检索如启用需副本/索引删除传播，当前无此实现
- 本地 本次引用/来源快照：现有 id,kind,objectId,version,sectionId,title,excerpt,status,scope；计划 ownerSpaceId/sourceRef/objectRevision/selectedScope/executedSnapshot/revocationState；草稿引用可移除；正式发送先校验来源与版本；历史执行快照和当前可用状态分开；不自动读取全部历史
- 本地 对话与AI请求：现有 assistantDraft,assistantSources；conversations{id,title,persist,draft,draftSources,messages,generating,requestId,pendingRequest,interrupted,updatedLabel}；message{id,role,text,sources,requestId,createdAt,status}；计划 accountId/spaceId/conversationId/messageId/logicalRequestId/operationKind/sourceSnapshotId/status/sequence/retentionScope；草稿本机；非留存对话仅内存。真实AI外发所选正文至明确供应方/云服务；服务端与供应商留存期D-06/08未定，不能承诺零留存
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-028, ZY-FR-029, ZY-FR-030, ZY-NFR-016, ZY-DATA-005
- 验收ID：T-FR-028-N, T-FR-028-E1, T-FR-028-E2, T-FR-028-E3, T-FR-029-N, T-FR-029-E1, T-FR-029-E2, T-FR-029-E3, T-FR-030-N, T-FR-030-E1, T-FR-030-E2, T-FR-030-E3, T-NFR-016-N, T-DATA-005, T-LEG-07
- 待决：D-05 首版完整价值切片（产品负责人，必要时由测量/法律/工程专业方协助）；D-08 空间、留存与备份（产品负责人，必要时由测量/法律/工程专业方协助）

## 小尝试列表 · actions

- 主线：选择小尝试→回看观察
- 最小价值：找回本人选择的计划与实际观察
- 前置：无需登录，不由AI自动创建
- 出入与返回：me/report/conversation/topic→actions；新建弹层→action-detail
- 当前边界：提醒只有需求，没有通知调度；放下不删除历史
- 实际/计划状态：空, active, reviewed, cancelled

### 按钮与事件

- back · 我的：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- new-action · 新建 / 写一个小尝试：V2生成可改表单；专题需已保存版本；同文字同来源revision且active时复用；保存后action-detail；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 只记观察，不安排事情观察可以独立存在：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 审计用虚构小尝试本人选择的尝试：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- submit-dialog · 保存到本机：调用当前dialogCallback；submit先trim且不能为空；confirm先关闭再执行；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- actions.local-interaction [local] 页面进入、输入或本人点击本页现有操作。请求：本页明确对象ID/版本及必要字段；返回：本机内容或保存/恢复状态
- 本地 小尝试与实际回看：现有 id,text,revision,status,sourceId,sourceKind,sourceVersion,sourceSnapshot,sectionId,reviews{id,outcome,text,actionText,actionRevision,createdAt},createdAt；计划 spaceId/actionId/reviewId/sourceRevision/reviewSubmitToken；本机本人决定；计划与实际观察独立；修改计划不改历史回看；提醒额外授权后才启用
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-031, ZY-FR-035
- 验收ID：T-FR-031-N, T-FR-031-E1, T-FR-031-E2, T-FR-035-N, T-FR-035-E1, T-FR-035-E2
- 待决：D-05 首版完整价值切片（产品负责人，必要时由测量/法律/工程专业方协助）

## 本人观察 · journal

- 主线：记录→保留→按需引用
- 最小价值：留下、修改或删除亲历记录
- 前置：本机空间可写；已有ID必须真实存在
- 出入与返回：me/records/daily说明→journal；保存/删除→records
- 当前边界：文字是本人自述，非已核验事实/测评分数；删除连带来源正文范围须明确
- 实际/计划状态：新建, 修改本人观察, 修改报告补充, 空提交, 写失败, 缺失

### 按钮与事件

- back · 返回：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- save-journal · 保存这个时刻 / 保存修改：V2取草稿非空；旧ID修改revision或新增note；清草稿回records；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- delete-journal · 删除这条记录：确认后删记录/旧修订/草稿与新引用；关联action来源全文清掉但计划和观察保留；回records；当前真实出网=无；计划位置=undecided；同名操作语义保留；正式实现尚未接入/验证
- confirm-dialog · 删除这条记录：调用当前dialogCallback；submit先trim且不能为空；confirm先关闭再执行；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- journal.local-interaction [local] 页面进入、输入或本人点击本页现有操作。请求：本页明确对象ID/版本及必要字段；返回：本机内容或保存/恢复状态
- 本地 本人观察与专题整理：现有 id,kind,topicId,title,fields,text,revision,revisions{revision,fields,text,createdAt},sourceId,sourceKind,sectionId,createdAt,updatedAt；计划 ownerSpaceId/recordId/sourceRefs/currentRevision/explicitConsent；自述与测量事实分别标识；本人本机；历史修订保留；删除同时处理草稿与关联来源全文，已导出副本不可撤回
- 本地 编辑草稿/未保存选择：现有 editorDrafts{journal:id,topic:topicId:id,report:context,action-review:id}；pendingAnswer内存；V2.cachedDrafts/failedDrafts内存；计划 draftId/ownerSpaceId/objectId/baseRevision/updatedAt/saveStatus；本机；失败不清输入，迁移需独立预检；原型LocalStorage明文并非APP方案
- 本地 本次引用/来源快照：现有 id,kind,objectId,version,sectionId,title,excerpt,status,scope；计划 ownerSpaceId/sourceRef/objectRevision/selectedScope/executedSnapshot/revocationState；草稿引用可移除；正式发送先校验来源与版本；历史执行快照和当前可用状态分开；不自动读取全部历史
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-018, ZY-FR-032, ZY-FR-010, ZY-DATA-005
- 验收ID：T-FR-018-N, T-FR-018-E1, T-FR-018-E2, T-FR-032-N, T-FR-032-E1, T-FR-032-E2, T-FR-010-N, T-FR-010-E1, T-FR-010-E2, T-DATA-005, T-LEG-07
- 待决：D-05 首版完整价值切片（产品负责人，必要时由测量/法律/工程专业方协助）；D-08 空间、留存与备份（产品负责人，必要时由测量/法律/工程专业方协助）

## 正在认识的自己 · portrait

- 主线：来源汇集→保留未知
- 最小价值：查看认识来源与未知，不把样例当本人结论
- 前置：当前无正式测量证据；只计本人观察/报告补充/确认记忆
- 出入与返回：me→portrait；来源分类records/memories；新增journal
- 当前边界：当前静态关系图+来源计数；洞察详情、按情境画像、缺口、异议/协调未实现
- 实际/计划状态：无依据, 有自述, 部分未知

### 按钮与事件

- back · 我的：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 本人观察0 条 · 由你写下，不是测量结果 / 报告补充0 条 · 本人陈述与原解释分开 / 本人观察2 条 · 由你写下，不是测量结果 / 报告补充1 条 · 本人陈述与原解释分开：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 确认的记忆0 条 · 仅显示仍有效的认识：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 再留下一条观察：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- portrait.reconcile [undecided] 本人明确查看/纠正画像时。请求：已授权来源及修订,纠正意见；返回：按情境/来源保留冲突和未知；算法与存储待定
- 本地 本人观察与专题整理：现有 id,kind,topicId,title,fields,text,revision,revisions{revision,fields,text,createdAt},sourceId,sourceKind,sectionId,createdAt,updatedAt；计划 ownerSpaceId/recordId/sourceRefs/currentRevision/explicitConsent；自述与测量事实分别标识；本人本机；历史修订保留；删除同时处理草稿与关联来源全文，已导出副本不可撤回
- 本地 长期记忆：现有 id,text,status(candidate/active/inactive),revision,sourceId,sourceMessageId,sourceType,sourceTitle；计划 memoryId/ownerSpaceId/sourceRevision/confirmedAt/validity/revocationRevision；逐条本人确认；修订回候选；停用阻断新检索与在途采用。云检索如启用需副本/索引删除传播，当前无此实现
- 本地 正式结果/报告：现有 当前仅独立report-sample-01与示意factor值；不存在真实result对象；计划 resultId/sessionId/reportVersion/contentVersion/scoringVersion/normVersion/factorValues/unknownFlags/qualityFlag/interpretationEvidence；本地计算、本地报告均候选未决；必须确定性可复现。若决定会员云保存，另定授权范围/留存/删除，不默认上传答案
- 本地 本次引用/来源快照：现有 id,kind,objectId,version,sectionId,title,excerpt,status,scope；计划 ownerSpaceId/sourceRef/objectRevision/selectedScope/executedSnapshot/revocationState；草稿引用可移除；正式发送先校验来源与版本；历史执行快照和当前可用状态分开；不自动读取全部历史
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-026, ZY-FR-027, ZY-AI-001, ZY-MEAS-007
- 验收ID：T-FR-026-N, T-FR-026-E1, T-FR-026-E2, T-FR-026-E3, T-FR-026-R1-SOURCE, T-FR-027-N, T-FR-027-E1, T-FR-027-E2, T-FR-027-E3, T-AI-001, T-MEAS-007, T-LEG-12
- 待决：D-04 计分常模与适用性（产品负责人，必要时由测量/法律/工程专业方协助）；D-05 首版完整价值切片（产品负责人，必要时由测量/法律/工程专业方协助）；D-06 AI供应商与数据用途（产品负责人，必要时由测量/法律/工程专业方协助）；D-13 安全与专业审校（产品负责人，必要时由测量/法律/工程专业方协助）；D-17 每日选题与画像更新策略（产品负责人，必要时由测量/内容/工程专业方协助）

## 我的数据 · data

- 主线：可见范围→导出/导入/清理
- 最小价值：拿走资料、预检旧版、理解本机和云端区别
- 前置：当前本机空间；导入文件显式由用户选择
- 出入与返回：me/settings→data；content；清理后home；取消不变
- 当前边界：原型LocalStorage+明文JSON不是正式APP存储方案；仅空空间旧版复制，不是完整合并或云同步
- 实际/计划状态：空, 有记录, 导出选类, 空空间导入, 非空拒绝, 文件无效, 写失败, 冲突

### 按钮与事件

- back · 我的：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- export-preview · 选择导出资料先预览类别，再生成 JSON 备份：显示sessions/notes/conversations/memories/orders勾选，conversations默认不选；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- import-spec · 导入与冲突处理本轮只提供流程规格，未实现导入方案：完整导入与冲突流程仅说明；另有V4空空间复制，须避免两入口矛盾；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- sync-spec · 备份和跨设备同步未接入；不显示“已同步”未接入：备份/同步仅说明，无真实服务；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 本地内容包查看当前实际包含的演示内容：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- clear-confirm · 清理演示数据仅清理当前体验空间；不会清除其他站点：明确确认后只清当前场景key；取消定时任务，回默认home；异常先导出；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- v4-import · 检查旧版或导入文件：非空空间拒绝；空空间读同来源V2/V3或用户JSON；5MB上限；预检后确认；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- export-data · 生成选定范围的文件：按勾选生成明文JSON；排除未选类，notes未选则删action来源全文；浏览器下载；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- close-dialog · 取消：关闭弹层、解除inert/滚动锁、回焦点；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- confirm-dialog · 清理当前演示空间：调用当前dialogCallback；submit先trim且不能为空；confirm先关闭再执行；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- v4-legacy · 同来源 V2 / V3 空间：读取合法命名的同来源V2/V3 LocalStorage并预检；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- v4-import-confirm · 复制到当前空间：重复检查空空间/blocked/importCandidate；replaceState成功后替换，清候选；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- close-dialog · 返回 / 取消：关闭弹层、解除inert/滚动锁、回焦点；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- backup.sync [undecided] 只有云保存/同步方案和明确授权成立后。请求：选定实体/修订/ownerScope/冲突规则；返回：逐对象同步状态，不能以登录当已同步
- import.commit [local] 导入预检、范围/冲突决定后。请求：已验证importPlan/schema/manifest；返回：事务结果明细、回滚/失败恢复
- 本地 答卷：现有 id,kind,version,mode,status,index,answers{questionId:optionId},createdAt,updatedAt,updatedLabel,activeSession；计划 spaceId/sessionId/assessmentId/contentVersion/scoringVersion/answerRevision/saveState/submitToken/resultId?；本机个人空间；完成后只读快照；保留时长与清理策略待D-08，云副本不是默认
- 本地 本人观察与专题整理：现有 id,kind,topicId,title,fields,text,revision,revisions{revision,fields,text,createdAt},sourceId,sourceKind,sectionId,createdAt,updatedAt；计划 ownerSpaceId/recordId/sourceRefs/currentRevision/explicitConsent；自述与测量事实分别标识；本人本机；历史修订保留；删除同时处理草稿与关联来源全文，已导出副本不可撤回
- 本地 对话与AI请求：现有 assistantDraft,assistantSources；conversations{id,title,persist,draft,draftSources,messages,generating,requestId,pendingRequest,interrupted,updatedLabel}；message{id,role,text,sources,requestId,createdAt,status}；计划 accountId/spaceId/conversationId/messageId/logicalRequestId/operationKind/sourceSnapshotId/status/sequence/retentionScope；草稿本机；非留存对话仅内存。真实AI外发所选正文至明确供应方/云服务；服务端与供应商留存期D-06/08未定，不能承诺零留存
- 本地 长期记忆：现有 id,text,status(candidate/active/inactive),revision,sourceId,sourceMessageId,sourceType,sourceTitle；计划 memoryId/ownerSpaceId/sourceRevision/confirmedAt/validity/revocationRevision；逐条本人确认；修订回候选；停用阻断新检索与在途采用。云检索如启用需副本/索引删除传播，当前无此实现
- 本地 小尝试与实际回看：现有 id,text,revision,status,sourceId,sourceKind,sourceVersion,sourceSnapshot,sectionId,reviews{id,outcome,text,actionText,actionRevision,createdAt},createdAt；计划 spaceId/actionId/reviewId/sourceRevision/reviewSubmitToken；本机本人决定；计划与实际观察独立；修改计划不改历史回看；提醒额外授权后才启用
- 本地 展示与隐私偏好：现有 name,avatar,avatarFamily,theme,density,fontSize,reduced,workspaceMode,chatRetention,memoryEnabled；不含真实画像；计划 settingsVersion/ownerScope/accessibilityOverrides/consentVersions；与推断画像分离；本机展示偏好；云同步若选用须明确字段；关闭留存只作用后续会话，不伪称删历史
- 本地 导出/导入/分享快照：现有 导出schema/groups/exportedAt/scope；importCandidate内存；固定SVG；不恢复认证/权益；计划 exportId/snapshotScope/schemaVersion/manifest/checksum/importPlan/conflictChoices/resultItems；文件写至用户选择目的地；明文风险显式告知；删除本机无法远程删已导出；云分享仅明确启用时生成最小快照
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 待修/待验：完整导入文字仍称未实现，V4另有空空间复制；应合并为同一入口的能力分层，防文案矛盾
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-045, ZY-FR-046, ZY-FR-047, ZY-FR-048, ZY-DATA-004, ZY-DATA-005, ZY-DATA-006, ZY-DATA-007
- 验收ID：T-FR-045-N, T-FR-045-E1, T-FR-045-E2, T-FR-045-E3, T-FR-046-N, T-FR-046-E1, T-FR-046-E2, T-FR-046-E3, T-FR-047-N, T-FR-047-E1, T-FR-047-E2, T-FR-047-E3, T-FR-048-N, T-FR-048-E1, T-FR-048-E2, T-FR-048-E3, T-DATA-004, T-DATA-005, T-LEG-07, T-DATA-006, T-DATA-006-R2-REDACT, T-DATA-006-R3-FILE, T-DATA-006-R3-CANCEL, T-DATA-007, T-DATA-007-R3-ROUNDTRIP, T-DATA-007-R3-CORRUPT
- 待决：D-02 16PF题源与授权（产品负责人，必要时由测量/法律/工程专业方协助）；D-08 空间、留存与备份（产品负责人，必要时由测量/法律/工程专业方协助）；D-11 平台与发布顺序（产品负责人，必要时由测量/法律/工程专业方协助）；D-14 设备与质量目标（产品负责人，必要时由测量/法律/工程专业方协助）；D-22 朋友圈分享分端接入（产品负责人，开发接入时与工程核验）；PAGE-ARCH-CANDIDATE 本地计算/本地报告/会员云保存（产品负责人和客户端/服务端工程，专业与隐私审校按需参与）

## 会员与用量规则 · membership

- 主线：清楚权益→购买前确认
- 最小价值：理解免费规则与待定付费方案
- 前置：AI访客0、登录非会员共享10/日；商品尚未售卖
- 出入与返回：me/额度→membership；checkout；orders；取消回原任务
- 当前边界：价格、付费额度、续费和重叠购买待定；升级/到期/退款不重置已用量
- 实际/计划状态：月, 年选择, 未定价, 演示用量, 恢复说明

### 按钮与事件

- back · 返回：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 订单：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- plan · 月方案价格待定按月了解服务 · 具体权益待定 / 年方案价格待定更长期的服务方向 · 具体权益待定：state.plan选择monthly/annual并本机保存；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- checkout-start · 查看购买确认演示：设checkoutReturn=membership→checkout；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- quota · 查看 AI 演示用量分析与对话共用，不拆成两份：本机演示used与10剩余说明，内含usage弹层入口；当前真实出网=无；计划位置=cloud；同名操作语义保留；正式实现尚未接入/验证
- restore-spec · 已有购买恢复 / 续费管理必须按真实支付渠道能力开放方案：购买恢复/续费说明，无真实核验；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 查看用量明细：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- close-dialog · 继续原来的任务：关闭弹层、解除inert/滚动锁、回焦点；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- offers.read [cloud] 真实售卖启用后进入方案页。请求：已知账号/渠道,客户端能力版本；返回：有效商品/报价/周期/权益/续费/售后条件
- purchase.restore [cloud] 本人点击恢复且渠道支持。请求：accountId,channel,原交易证据；返回：已有权益，不重买也不等于资料恢复
- 本地 权益：现有 orders[].entitlement仅模拟；state.plan为当前选择；计划 entitlementId/accountId/sourceOrderId/policyVersion/validFrom/validTo/status；服务端单一事实；付款成功与权益生效分开；到期/退款不改用量账本；历史资料访问策略D-09/10待定
- 本地 订单/支付/退款：现有 id(DEMO),plan,planVersion,payment,entitlement,returnTo,createdAt；计划 orderId/accountId/planSnapshot/quoteVersion/priceCurrency/channel/originalTransactionId/paymentFact/refundId/refundStatus/idempotencyKey；真实交易事实云权威+支付渠道核验；本机仅最小只读缓存；保存周期依财务与法规待定，不自行设年限
- 本地 AI用量账本：现有 used,usageDay,usage{id,kind,status,createdAt}；全部本机演示可绕过；计划 accountId/dayKey/logicalRequestId/kind/settlementState/quotaPolicyVersion/used/remaining；真实额度云端按账号跨设备统一；访客0，登录非会员分析+chat合计10/日；升级、到期、退款不重置已用量；日界线和失败/停止结算D-07未决
- 本地 页面上下文：现有 route,params{id,topic,kind,tab},stack,scrolls,recordFilter,exploreCategory,exploreSearch,returnAfterAuth,checkoutReturn；计划 route/objectId/returnIntent/scrollAnchor；正文不进URL；本机UI上下文；内存与偏好保存边界由工程定；不需云端
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-050, ZY-FR-023, ZY-FR-054, ZY-BIZ-001, ZY-BIZ-003
- 验收ID：T-FR-050-N, T-FR-050-E1, T-FR-050-E2, T-FR-050-E3, T-FR-023-N, T-FR-023-E1, T-FR-023-E2, T-FR-023-E3, T-FR-023-R2-SHARED, T-FR-023-R3-DAILYAI-1, T-FR-023-R3-DAILYAI-2, T-FR-023-R3-DAILYAI-3, T-FR-023-R3-DAILYAI-4, T-FR-054-N, T-FR-054-E1, T-FR-054-E2, T-FR-054-E3, T-BIZ-001, T-LEG-11, T-BIZ-003
- 待决：D-06 AI供应商与数据用途（产品负责人，必要时由测量/法律/工程专业方协助）；D-07 共享次数与计量（产品负责人，必要时由测量/法律/工程专业方协助）；D-09 商业模式与权益（产品负责人，必要时由测量/法律/工程专业方协助）；D-10 支付与售后（产品负责人，必要时由测量/法律/工程专业方协助）；D-17 每日选题与画像更新策略（产品负责人，必要时由测量/内容/工程专业方协助）；D-21 账号关联与防重复领额度（产品负责人，开发接入时与工程核验）

## 购买确认 · checkout

- 主线：方案快照→同一订单→支付返回
- 最小价值：确认身份、报价与交易条件后决定购买
- 前置：真实购买需登录、有效报价和支付渠道；当前仅DEMO
- 出入与返回：membership→checkout；create→order；cancel→checkoutReturn
- 当前边界：原型每次create-order生成新ID，缺少正式幂等；不得把模拟创建当订单服务
- 实际/计划状态：方案快照, 创建中, 取消, 支付未知, 失败

### 按钮与事件

- back · 返回方案：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- create-order · 创建演示订单：每次生成DEMO ID与planVersion快照、payment/entitlement pending→order；当前真实出网=无；计划位置=cloud；同名操作语义保留；正式实现尚未接入/验证
- cancel-checkout · 取消，保留原草稿：回checkoutReturn或订单returnTo；不改草稿；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- order.create [cloud] 本人确认完整报价与条款后。请求：accountId,quoteVersion,channel,idempotencyKey；返回：orderId/原方案快照/渠道调用参数/状态
- 本地 订单/支付/退款：现有 id(DEMO),plan,planVersion,payment,entitlement,returnTo,createdAt；计划 orderId/accountId/planSnapshot/quoteVersion/priceCurrency/channel/originalTransactionId/paymentFact/refundId/refundStatus/idempotencyKey；真实交易事实云权威+支付渠道核验；本机仅最小只读缓存；保存周期依财务与法规待定，不自行设年限
- 本地 权益：现有 orders[].entitlement仅模拟；state.plan为当前选择；计划 entitlementId/accountId/sourceOrderId/policyVersion/validFrom/validTo/status；服务端单一事实；付款成功与权益生效分开；到期/退款不改用量账本；历史资料访问策略D-09/10待定
- 本地 身份/关联/会话：现有 仅logged布尔，无密码验证码和真实账号；计划 accountId/providerSubject映射/verifiedPhone关联/sessionStatus/consentVersion/spaceClaimChoice/abuseEvidence最小集；认证与共享额度必须云权威；验证码不明文留存；令牌安全系统存储方案待定；本机资料认领不等于云上传
- 本地 页面上下文：现有 route,params{id,topic,kind,tab},stack,scrolls,recordFilter,exploreCategory,exploreSearch,returnAfterAuth,checkoutReturn；计划 route/objectId/returnIntent/scrollAnchor；正文不进URL；本机UI上下文；内存与偏好保存边界由工程定；不需云端
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 待修/待验：create-order每次新建随机DEMO ID，无生产订单幂等
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-051, ZY-FR-052, ZY-BIZ-004, ZY-BIZ-005
- 验收ID：T-FR-051-N, T-FR-051-E1, T-FR-051-E2, T-FR-051-E3, T-FR-052-N, T-FR-052-E1, T-FR-052-E2, T-FR-052-E3, T-BIZ-004, T-BIZ-005
- 待决：D-09 商业模式与权益（产品负责人，必要时由测量/法律/工程专业方协助）；D-10 支付与售后（产品负责人，必要时由测量/法律/工程专业方协助）

## 订单记录 · orders

- 主线：原单找回→交易核对
- 最小价值：找回停售方案对应的原订单
- 前置：真实账号归属；原型只本机演示单
- 出入与返回：membership→orders→order?id；回列表保留位置
- 当前边界：无真实支付查询或购买恢复
- 实际/计划状态：空, 有旧单, 查询失败, 无权限

### 按钮与事件

- back · 我的：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 了解使用规则：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 演示订单年方案DEMO-ANNUAL-001pending:pending：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- orders.list [cloud] 本人查看本人订单。请求：accountId,cursor/filter；返回：本人订单摘要，含旧方案快照
- 本地 订单/支付/退款：现有 id(DEMO),plan,planVersion,payment,entitlement,returnTo,createdAt；计划 orderId/accountId/planSnapshot/quoteVersion/priceCurrency/channel/originalTransactionId/paymentFact/refundId/refundStatus/idempotencyKey；真实交易事实云权威+支付渠道核验；本机仅最小只读缓存；保存周期依财务与法规待定，不自行设年限
- 本地 权益：现有 orders[].entitlement仅模拟；state.plan为当前选择；计划 entitlementId/accountId/sourceOrderId/policyVersion/validFrom/validTo/status；服务端单一事实；付款成功与权益生效分开；到期/退款不改用量账本；历史资料访问策略D-09/10待定
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-052, ZY-FR-053, ZY-FR-054, ZY-BR-003
- 验收ID：T-FR-052-N, T-FR-052-E1, T-FR-052-E2, T-FR-052-E3, T-FR-053-N, T-FR-053-E1, T-FR-053-E2, T-FR-053-E3, T-FR-054-N, T-FR-054-E1, T-FR-054-E2, T-FR-054-E3, T-BR-003-N
- 待决：D-09 商业模式与权益（产品负责人，必要时由测量/法律/工程专业方协助）；D-10 支付与售后（产品负责人，必要时由测量/法律/工程专业方协助）

## 订单与售后 · order

- 主线：支付事实→权益→退款处理
- 最小价值：核对原单状态并处理售后
- 前置：orderId与本人账号；原方案快照不可被现售方案覆盖
- 出入与返回：orders/checkout→order?id；order-return→原任务；退款就地
- 当前边界：当前按钮改本机枚举；支付事实/权益/退款三者分离；无到账核验
- 实际/计划状态：pending, paid权益pending, active, refunding, refunded, 不存在

### 按钮与事件

- back · 返回 / 返回订单：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 回到列表：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- order-paid · 演示：付款已核验：手动模拟订单payment=paid或entitlement=active；未校渠道；当前真实出网=无；计划位置=local；演示专用：不得进入正式APP；正式业务另见page.plannedOperations
- order-return · 回到原来的任务：回checkoutReturn或订单returnTo；不改草稿；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- order-active · 演示：权益已生效：手动模拟订单payment=paid或entitlement=active；未校渠道；当前真实出网=无；计划位置=local；演示专用：不得进入正式APP；正式业务另见page.plannedOperations
- refund · 查看退款申请演示：确认后仅把演示payment改refunding；没有到账；当前真实出网=无；计划位置=cloud；同名操作语义保留；正式实现尚未接入/验证
- refund-info · 查看退款进度说明：退款申请与到账区别说明，无真实查询；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- confirm-dialog · 演示提交申请：调用当前dialogCallback；submit先trim且不能为空；confirm先关闭再执行；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- order.verify [cloud] 支付返回、恢复页面或本人重查。请求：accountId,orderId；返回：支付事实/权益分别核验，不重复下单
- refund.apply [cloud] 已验证订单上本人确认退款。请求：orderId,refundRequestId,reason；返回：退款申请/渠道/到账各状态
- 本地 订单/支付/退款：现有 id(DEMO),plan,planVersion,payment,entitlement,returnTo,createdAt；计划 orderId/accountId/planSnapshot/quoteVersion/priceCurrency/channel/originalTransactionId/paymentFact/refundId/refundStatus/idempotencyKey；真实交易事实云权威+支付渠道核验；本机仅最小只读缓存；保存周期依财务与法规待定，不自行设年限
- 本地 权益：现有 orders[].entitlement仅模拟；state.plan为当前选择；计划 entitlementId/accountId/sourceOrderId/policyVersion/validFrom/validTo/status；服务端单一事实；付款成功与权益生效分开；到期/退款不改用量账本；历史资料访问策略D-09/10待定
- 本地 AI用量账本：现有 used,usageDay,usage{id,kind,status,createdAt}；全部本机演示可绕过；计划 accountId/dayKey/logicalRequestId/kind/settlementState/quotaPolicyVersion/used/remaining；真实额度云端按账号跨设备统一；访客0，登录非会员分析+chat合计10/日；升级、到期、退款不重置已用量；日界线和失败/停止结算D-07未决
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-052, ZY-FR-053, ZY-FR-054, ZY-BR-003, ZY-BIZ-004
- 验收ID：T-FR-052-N, T-FR-052-E1, T-FR-052-E2, T-FR-052-E3, T-FR-053-N, T-FR-053-E1, T-FR-053-E2, T-FR-053-E3, T-FR-054-N, T-FR-054-E1, T-FR-054-E2, T-FR-054-E3, T-BR-003-N, T-BIZ-004
- 待决：D-09 商业模式与权益（产品负责人，必要时由测量/法律/工程专业方协助）；D-10 支付与售后（产品负责人，必要时由测量/法律/工程专业方协助）

## 概念阅读 · article

- 主线：概念理解→带出处提问
- 最小价值：读解释并只引用选定片段
- 前置：当前article-demo-v1为原创阅读示例
- 出入与返回：explore→article?id；引用→assistant草稿；返回原阅读位置
- 当前边界：按钮写选中片段但实现固定article-excerpt；正式APP需明确真实选段语义
- 实际/计划状态：阅读, 选段空, 正文不可用, 版本撤回

### 按钮与事件

- back · 认识：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- article-quote · 拿选中的这段，问问助理：V2.attachSource去重/更新来源版本并填默认草稿→assistant；topic脏草稿须选已存版；文章固定quote-1非真实选段；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- article.local-interaction [local] 页面进入、输入或本人点击本页现有操作。请求：本页明确对象ID/版本及必要字段；返回：本机内容或保存/恢复状态
- 本地 题库/阅读/专题包：现有 D.questions{3个原创questionId,title,options}；D.topics{5个topicId,category,prompts}；D.report；D.factors；均随JS静态提供；计划 packId/contentVersion/assessmentId/questionId/optionId/licenseEvidence/eligibilityStatus/scoringVersion/normVersion/checksum；全部发布题库默认随安装本地；首启不依赖下载。资格不成立不分发正式内容；更新/撤回保留旧任务版本。更新服务如启用仅请求包和版本元数据
- 本地 本次引用/来源快照：现有 id,kind,objectId,version,sectionId,title,excerpt,status,scope；计划 ownerSpaceId/sourceRef/objectRevision/selectedScope/executedSnapshot/revocationState；草稿引用可移除；正式发送先校验来源与版本；历史执行快照和当前可用状态分开；不自动读取全部历史
- 本地 对话与AI请求：现有 assistantDraft,assistantSources；conversations{id,title,persist,draft,draftSources,messages,generating,requestId,pendingRequest,interrupted,updatedLabel}；message{id,role,text,sources,requestId,createdAt,status}；计划 accountId/spaceId/conversationId/messageId/logicalRequestId/operationKind/sourceSnapshotId/status/sequence/retentionScope；草稿本机；非留存对话仅内存。真实AI外发所选正文至明确供应方/云服务；服务端与供应商留存期D-06/08未定，不能承诺零留存
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 待修/待验：“选中的这段”实际固定quote-1片段，未读取用户真实文本选择
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-019, ZY-FR-022
- 验收ID：T-FR-019-N, T-FR-019-E1, T-FR-019-E2, T-FR-022-N, T-FR-022-E1, T-FR-022-E2, T-FR-022-E3
- 待决：D-05 首版完整价值切片（产品负责人，必要时由测量/法律/工程专业方协助）；D-06 AI供应商与数据用途（产品负责人，必要时由测量/法律/工程专业方协助）；D-07 共享次数与计量（产品负责人，必要时由测量/法律/工程专业方协助）

## 分享预览 · share

- 主线：本人选择范围→预览→外发
- 最小价值：只分享明确确认的部分
- 前置：正式分享需本人可访问对象和清晰风险提示
- 出入与返回：report→share；导出本机文件；返回原段
- 当前边界：目前只固定脱敏SVG样例，不是16PF结果/AI画像朋友圈双分享，SDK分端待定
- 实际/计划状态：固定样例, 生成中, 生成失败, 授权拒绝, 分享取消

### 按钮与事件

- back · 返回报告：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- export-share · 导出这张分享图：固定脱敏样例生成SVG并下载；当前真实出网=无；计划位置=undecided；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- share.render [local] 本人选择字段并确认预览后。请求：分享对象/版本,允许字段,脱敏规则；返回：与预览一致图文件
- moments.invoke [undecided] 用户主动选择朋友圈且平台能力允许。请求：仅已确认分享图/文案与必要SDK参数；返回：平台回执或取消；分端D-22待定
- 本地 正式结果/报告：现有 当前仅独立report-sample-01与示意factor值；不存在真实result对象；计划 resultId/sessionId/reportVersion/contentVersion/scoringVersion/normVersion/factorValues/unknownFlags/qualityFlag/interpretationEvidence；本地计算、本地报告均候选未决；必须确定性可复现。若决定会员云保存，另定授权范围/留存/删除，不默认上传答案
- 本地 导出/导入/分享快照：现有 导出schema/groups/exportedAt/scope；importCandidate内存；固定SVG；不恢复认证/权益；计划 exportId/snapshotScope/schemaVersion/manifest/checksum/importPlan/conflictChoices/resultItems；文件写至用户选择目的地；明文风险显式告知；删除本机无法远程删已导出；云分享仅明确启用时生成最小快照
- 本地 展示与隐私偏好：现有 name,avatar,avatarFamily,theme,density,fontSize,reduced,workspaceMode,chatRetention,memoryEnabled；不含真实画像；计划 settingsVersion/ownerScope/accessibilityOverrides/consentVersions；与推断画像分离；本机展示偏好；云同步若选用须明确字段；关闭留存只作用后续会话，不伪称删历史
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-013, ZY-DATA-006, ZY-UX-012
- 验收ID：T-FR-013-N, T-FR-013-E1, T-FR-013-E2, T-FR-013-R2-REPORT, T-FR-013-R2-PORTRAIT, T-FR-013-R2-UNAVAILABLE, T-FR-013-R3-SOURCECHANGE-1, T-FR-013-R3-SOURCECHANGE-2, T-FR-013-R3-ACCESS, T-FR-013-R3-REVOKE, T-DATA-006, T-DATA-006-R2-REDACT, T-DATA-006-R3-FILE, T-DATA-006-R3-CANCEL, T-UX-012
- 待决：D-02 16PF题源与授权（产品负责人，必要时由测量/法律/工程专业方协助）；D-05 首版完整价值切片（产品负责人，必要时由测量/法律/工程专业方协助）；D-08 空间、留存与备份（产品负责人，必要时由测量/法律/工程专业方协助）；D-14 设备与质量目标（产品负责人，必要时由测量/法律/工程专业方协助）；D-16 内容与支持运营（产品负责人，必要时由测量/法律/工程专业方协助）；D-22 朋友圈分享分端接入（产品负责人，开发接入时与工程核验）

## 设置 · settings

- 主线：统一偏好与资料控制
- 最小价值：调整阅读并到具体管理页
- 前置：本机设置无账号；系统权限按需申请
- 出入与返回：me→settings；appearance/privacy/account/data/support
- 当前边界：助理语气偏好未实现；麦克风相机定位通知未申请
- 实际/计划状态：标准, 大字, 密度弹层, 减少动态

### 按钮与事件

- back · 我的：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 主题与形象八套主题、独立人物选择：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- v3-preferences · 阅读密度与动态舒展、紧凑与减少动态：打开密度/减少动态弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 隐私与引用聊天、记忆、外发分别控制：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 账号与安全演示身份与本机空间分开：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 我的数据导出与清理范围：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 使用说明打开方式、演示限制与反馈：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- font-size · 标准 / 大字：校验允许枚举后写本机偏好并局部刷新；人物family与theme分开；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- v3-density · 舒展 / 紧凑：校验允许枚举后写本机偏好并局部刷新；人物family与theme分开；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- v3-motion · 减少动态：校验允许枚举后写本机偏好并局部刷新；人物family与theme分开；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- close-dialog · 按这个方式阅读：关闭弹层、解除inert/滚动锁、回焦点；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- settings.local-interaction [local] 页面进入、输入或本人点击本页现有操作。请求：本页明确对象ID/版本及必要字段；返回：本机内容或保存/恢复状态
- 本地 展示与隐私偏好：现有 name,avatar,avatarFamily,theme,density,fontSize,reduced,workspaceMode,chatRetention,memoryEnabled；不含真实画像；计划 settingsVersion/ownerScope/accessibilityOverrides/consentVersions；与推断画像分离；本机展示偏好；云同步若选用须明确字段；关闭留存只作用后续会话，不伪称删历史
- 本地 页面上下文：现有 route,params{id,topic,kind,tab},stack,scrolls,recordFilter,exploreCategory,exploreSearch,returnAfterAuth,checkoutReturn；计划 route/objectId/returnIntent/scrollAnchor；正文不进URL；本机UI上下文；内存与偏好保存边界由工程定；不需云端
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-040, ZY-FR-041, ZY-FR-044
- 验收ID：T-FR-040-N, T-FR-040-E1, T-FR-040-E2, T-FR-041-N, T-FR-041-E1, T-FR-041-E2, T-FR-044-N, T-FR-044-E1, T-FR-044-E2, T-FR-044-R3-SDK, T-FR-044-R3-PERMISSION
- 待决：D-08 空间、留存与备份（产品负责人，必要时由测量/法律/工程专业方协助）；D-12 视觉与资产定稿（产品负责人，必要时由测量/法律/工程专业方协助）；D-14 设备与质量目标（产品负责人，必要时由测量/法律/工程专业方协助）；D-16 内容与支持运营（产品负责人，必要时由测量/法律/工程专业方协助）；D-22 朋友圈分享分端接入（产品负责人，开发接入时与工程核验）

## 隐私与引用 · privacy

- 主线：本次引用/留存/记忆分别控制
- 最小价值：分别选择资料外发与保存，了解撤回边界
- 前置：本人空间；设置不等于具体AI请求同意
- 出入与返回：settings/me→privacy；memories/data；取消回原页
- 当前边界：关闭后续留存不删已有对话；设备锁/注销仅说明，正式政策未定
- 实际/计划状态：留存开关, 记忆候选开关, 注销说明, 设备保护说明

### 按钮与事件

- back · 返回：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- context-spec · 本次资料引用每次发送前选择，可逐条移除查看：一次引用/留存/长期记忆分别说明；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- toggle-chat-retention · 保存后续演示对话：切换独立本机布尔；不删历史；记忆开关不自动确认；当前真实出网=无；计划位置=undecided；同名操作语义保留；正式实现尚未接入/验证
- toggle-memory · 允许提出长期记忆候选：切换独立本机布尔；不删历史；记忆开关不自动确认；当前真实出网=无；计划位置=undecided；同名操作语义保留；正式实现尚未接入/验证
- nav · 已有记忆的纠正与停用停用后，不纳入新的演示引用：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 本机数据导出与清理不等于账号注销或云端删除：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- delete-account-spec · 账号注销范围仅设计流程，未接入真实账号方案：注销范围说明，未执行账号删除；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- device-spec · 设备私密保护候选功能，未接入系统认证方案：设备私密保护候选说明，无生物识别/设备凭据接入；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- consent.change [undecided] 本人改单独引用/留存/记忆控制。请求：scope,consentRevision,effectiveFrom；返回：仅对应范围状态和下游生效进度
- 本地 展示与隐私偏好：现有 name,avatar,avatarFamily,theme,density,fontSize,reduced,workspaceMode,chatRetention,memoryEnabled；不含真实画像；计划 settingsVersion/ownerScope/accessibilityOverrides/consentVersions；与推断画像分离；本机展示偏好；云同步若选用须明确字段；关闭留存只作用后续会话，不伪称删历史
- 本地 本次引用/来源快照：现有 id,kind,objectId,version,sectionId,title,excerpt,status,scope；计划 ownerSpaceId/sourceRef/objectRevision/selectedScope/executedSnapshot/revocationState；草稿引用可移除；正式发送先校验来源与版本；历史执行快照和当前可用状态分开；不自动读取全部历史
- 本地 长期记忆：现有 id,text,status(candidate/active/inactive),revision,sourceId,sourceMessageId,sourceType,sourceTitle；计划 memoryId/ownerSpaceId/sourceRevision/confirmedAt/validity/revocationRevision；逐条本人确认；修订回候选；停用阻断新检索与在途采用。云检索如启用需副本/索引删除传播，当前无此实现
- 本地 对话与AI请求：现有 assistantDraft,assistantSources；conversations{id,title,persist,draft,draftSources,messages,generating,requestId,pendingRequest,interrupted,updatedLabel}；message{id,role,text,sources,requestId,createdAt,status}；计划 accountId/spaceId/conversationId/messageId/logicalRequestId/operationKind/sourceSnapshotId/status/sequence/retentionScope；草稿本机；非留存对话仅内存。真实AI外发所选正文至明确供应方/云服务；服务端与供应商留存期D-06/08未定，不能承诺零留存
- 本地 身份/关联/会话：现有 仅logged布尔，无密码验证码和真实账号；计划 accountId/providerSubject映射/verifiedPhone关联/sessionStatus/consentVersion/spaceClaimChoice/abuseEvidence最小集；认证与共享额度必须云权威；验证码不明文留存；令牌安全系统存储方案待定；本机资料认领不等于云上传
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-022, ZY-FR-030, ZY-FR-039, ZY-FR-056, ZY-DATA-002, ZY-DATA-005
- 验收ID：T-FR-022-N, T-FR-022-E1, T-FR-022-E2, T-FR-022-E3, T-FR-030-N, T-FR-030-E1, T-FR-030-E2, T-FR-030-E3, T-FR-039-N, T-FR-039-E1, T-FR-039-E2, T-FR-039-R3-DELETESTATUS-1, T-FR-039-R3-DELETESTATUS-2, T-FR-039-R3-DELETESTATUS-3, T-FR-039-R3-OFFLINE, T-FR-039-R3-BACKUP, T-FR-056-N, T-FR-056-E1, T-FR-056-E2, T-FR-056-E3, T-DATA-002, T-LEG-05, T-DATA-005, T-LEG-07
- 待决：D-06 AI供应商与数据用途（产品负责人，必要时由测量/法律/工程专业方协助）；D-07 共享次数与计量（产品负责人，必要时由测量/法律/工程专业方协助）；D-08 空间、留存与备份（产品负责人，必要时由测量/法律/工程专业方协助）；D-16 内容与支持运营（产品负责人，必要时由测量/法律/工程专业方协助）；D-21 账号关联与防重复领额度（产品负责人，开发接入时与工程核验）

## 帮助与反馈 · support

- 主线：问题→反馈对象→进度/回复
- 最小价值：理解限制和恢复方法，提出可追踪问题
- 前置：真实渠道未接入；反馈不应默认带私人正文
- 出入与返回：settings→support；说明弹层；当前仅生成txt文件
- 当前边界：没有真实接收/进度/客服回复；不能称反馈已提交
- 实际/计划状态：说明, 编辑反馈, 本地下载, 计划提交失败与进度

### 按钮与事件

- back · 返回：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- demo-boundary · 哪些是真的，哪些是演示本地交互 / 预写回复 / 未接入服务阅读：原型/模拟/未接入范围说明；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- save-help · 保存失败时怎么办先留住输入，不要直接关页面阅读：保存失败恢复建议，只读说明；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- design-feedback · 如何给设计反馈给出页面、问题、希望发生什么记录：本机表单txt下载，不发送客服；当前真实出网=无；计划位置=cloud；同名操作语义保留；正式实现尚未接入/验证
- terms-spec · 协议与适用范围正式文本待真实产品方案确定说明：正式协议未就绪说明，不构成正式文本；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- submit-dialog · 保存到本机（实际生成反馈文件）：调用当前dialogCallback；submit先trim且不能为空；confirm先关闭再执行；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- feedback.submit [cloud] 用户同意选择范围后提交。请求：用户反馈,页面/对象最小上下文,明确同意附件,幂等ID；返回：真实feedbackId/受理状态
- feedback.progress [cloud] 本人查看处理结果。请求：feedbackId,本人授权；返回：进度/回复/后续问题
- 本地 反馈：现有 当前只编辑文本并本地下载txt，无反馈ID；计划 feedbackId/accountId?/page/objectId?/userProvidedText/consentedAttachmentScope/status/reply；真实接收方与最少上下文须明示；默认不附答案/聊天/心理标签；云端受理后才称提交成功
- 本地 题库/阅读/专题包：现有 D.questions{3个原创questionId,title,options}；D.topics{5个topicId,category,prompts}；D.report；D.factors；均随JS静态提供；计划 packId/contentVersion/assessmentId/questionId/optionId/licenseEvidence/eligibilityStatus/scoringVersion/normVersion/checksum；全部发布题库默认随安装本地；首启不依赖下载。资格不成立不分发正式内容；更新/撤回保留旧任务版本。更新服务如启用仅请求包和版本元数据
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-044, ZY-FR-049, ZY-BR-005, ZY-OPS-002, ZY-OPS-005
- 验收ID：T-FR-044-N, T-FR-044-E1, T-FR-044-E2, T-FR-044-R3-SDK, T-FR-044-R3-PERMISSION, T-FR-049-N, T-FR-049-E1, T-FR-049-E2, T-BR-005-N, T-OPS-002, T-OPS-005
- 待决：D-08 空间、留存与备份（产品负责人，必要时由测量/法律/工程专业方协助）；D-13 安全与专业审校（产品负责人，必要时由测量/法律/工程专业方协助）；D-16 内容与支持运营（产品负责人，必要时由测量/法律/工程专业方协助）；D-22 朋友圈分享分端接入（产品负责人，开发接入时与工程核验）

## 账号与安全 · account

- 主线：身份状态→恢复/退出/删除
- 最小价值：管理会话与资料归属
- 前置：真实身份未接入；本机空间与账号分开
- 出入与返回：me/settings→account；auth；退出原页保留本机
- 当前边界：退出停止本窗口计时任务；真会话撤销、号码变更、账号关联未实现
- 实际/计划状态：未登录, 演示登录, 退出确认, 恢复说明, 注销说明

### 按钮与事件

- back · 我的：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 注册 / 登录的连续流程返回原草稿，不自动发 AI / 了解登录与注册：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- recover-spec · 恢复账号需要实际认证方式与恢复证据方案：账号恢复说明，无身份验证；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- delete-account-spec · 注销账号的处理范围区分本机、应用云端和外部服务方案：注销范围说明，未执行账号删除；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- logout · 退出演示身份：确认后取消本窗口计时请求，logged=false；保留本机资料；当前真实出网=无；计划位置=cloud；同名操作语义保留；正式实现尚未接入/验证
- confirm-dialog · 退出演示：调用当前dialogCallback；submit先trim且不能为空；confirm先关闭再执行；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- identity.session.revoke [cloud] 本人确认退出/撤销会话。请求：sessionId,scope；返回：已撤销/unknown及重查路径
- identity.recover [cloud] 本人主动恢复账号。请求：已选验证渠道,必要证明,requestId；返回：恢复进度/拒绝/后续会话失效范围
- account.delete [cloud] 身份再验证与范围确认后。请求：accountId,deletionRequestId,confirmedScope；返回：受理/各处理阶段/失败与重试，不假称供应商已删
- 本地 身份/关联/会话：现有 仅logged布尔，无密码验证码和真实账号；计划 accountId/providerSubject映射/verifiedPhone关联/sessionStatus/consentVersion/spaceClaimChoice/abuseEvidence最小集；认证与共享额度必须云权威；验证码不明文留存；令牌安全系统存储方案待定；本机资料认领不等于云上传
- 本地 页面上下文：现有 route,params{id,topic,kind,tab},stack,scrolls,recordFilter,exploreCategory,exploreSearch,returnAfterAuth,checkoutReturn；计划 route/objectId/returnIntent/scrollAnchor；正文不进URL；本机UI上下文；内存与偏好保存边界由工程定；不需云端
- 本地 对话与AI请求：现有 assistantDraft,assistantSources；conversations{id,title,persist,draft,draftSources,messages,generating,requestId,pendingRequest,interrupted,updatedLabel}；message{id,role,text,sources,requestId,createdAt,status}；计划 accountId/spaceId/conversationId/messageId/logicalRequestId/operationKind/sourceSnapshotId/status/sequence/retentionScope；草稿本机；非留存对话仅内存。真实AI外发所选正文至明确供应方/云服务；服务端与供应商留存期D-06/08未定，不能承诺零留存
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-037, ZY-FR-038, ZY-FR-039, ZY-DATA-003, ZY-ENG-009
- 验收ID：T-FR-037-N, T-FR-037-E1, T-FR-037-E2, T-FR-037-E3, T-FR-037-R2-AUTH, T-FR-037-R2-SMS, T-FR-037-R2-CANCEL, T-FR-037-R3-STATE-1, T-FR-037-R3-STATE-2, T-FR-037-R3-STATE-3, T-FR-037-R3-CONFLICT-1, T-FR-037-R3-CONFLICT-2, T-FR-038-N, T-FR-038-E1, T-FR-038-E2, T-FR-038-E3, T-FR-038-R2-LIFECYCLE, T-FR-038-R3-RECOVERY-1, T-FR-038-R3-RECOVERY-2, T-FR-038-R3-RECOVERY-3, T-FR-039-N, T-FR-039-E1, T-FR-039-E2, T-FR-039-R3-DELETESTATUS-1, T-FR-039-R3-DELETESTATUS-2, T-FR-039-R3-DELETESTATUS-3, T-FR-039-R3-OFFLINE, T-FR-039-R3-BACKUP, T-DATA-003, T-DATA-003-R3-INTERRUPT, T-DATA-003-R3-SWITCH, T-ENG-009, T-LEG-04
- 待决：D-06 AI供应商与数据用途（产品负责人，必要时由测量/法律/工程专业方协助）；D-07 共享次数与计量（产品负责人，必要时由测量/法律/工程专业方协助）；D-08 空间、留存与备份（产品负责人，必要时由测量/法律/工程专业方协助）；D-11 平台与发布顺序（产品负责人，必要时由测量/法律/工程专业方协助）；D-16 内容与支持运营（产品负责人，必要时由测量/法律/工程专业方协助）；D-20 手机号绑定强制时机（产品负责人，开发接入时与工程核验）；D-21 账号关联与防重复领额度（产品负责人，开发接入时与工程核验）

## 旧单因子假设实验 · simulation

- 主线：概念学习→假设位置
- 最小价值：理解一个因子位置变化
- 前置：假设模式；无真实测量结论
- 出入与返回：explore旧工具入口或factor-sim→simulation；回原页
- 当前边界：这是旧单因子局部演示，与新16因子personality-sandbox并存，不可混称完整模拟功能
- 实际/计划状态：默认A, 切换16因子, 范围10–90示意

### 按钮与事件

- back · 认识：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- sim-factors · 换一个因子单因子仍然保持相同对象，不偷换为 A：展示16因子弹层；sim-factors设置选择模式；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- factor · {factorId} 切换假设角度：若sim-factors选模式则更新内存simFactor；否则展示该因子样例/未知与边界；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- factor-sim · 用这个角度做个假设：内存simFactor=id，跳旧simulation；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- close-dialog · 回到刚才的位置：关闭弹层、解除inert/滚动锁、回焦点；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- simulation.local-interaction [local] 页面进入、输入或本人点击本页现有操作。请求：本页明确对象ID/版本及必要字段；返回：本机内容或保存/恢复状态
- 本地 假设配置：现有 旧App.simFactor/simValue内存；新AssessmentPreview.scores/count/factor/answer/screen内存；计划 simulationId/factorMap/scaleVersion/explicitlySetMask/sourceKind=hypothesis；当前刷新清空不入个人记录；正式是否保存独立假设待D-19；不得入本人测量/画像
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：收敛新旧因子/每日/模拟重复入口；config/process/result可用同route子状态；当前UI-only必须明示，不能为占位造假业务。旧simulation与新sandbox保留差异后再决定合并
- 需求：ZY-FR-016, ZY-NFR-007
- 验收ID：T-FR-016-N, T-FR-016-E1, T-FR-016-E2, T-FR-016-R1-SIM, T-NFR-007-N
- 待决：D-02 16PF题源与授权（产品负责人，必要时由测量/法律/工程专业方协助）；D-03 AI重置版身份（产品负责人，必要时由测量/法律/工程专业方协助）；D-04 计分常模与适用性（产品负责人，必要时由测量/法律/工程专业方协助）；D-05 首版完整价值切片（产品负责人，必要时由测量/法律/工程专业方协助）；D-19 模拟性格量尺与假设分析（产品负责人，必要时由测量/内容/工程专业方协助）

## 两份结果比较 · compare

- 主线：先验证可比性→并列理解
- 最小价值：比较有依据的两份结果
- 前置：目前没有两份正式可比结果
- 出入与返回：records→compare→records；取消保留原选择
- 当前边界：当前说明页，没有选择器或计算；不同版本无依据不能平均或画趋势
- 实际/计划状态：当前空, 计划选择两份, 不可比, 可比, 版本失效

### 按钮与事件

- back · 记录：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 回到记录：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- compare.local-interaction [local] 页面进入、输入或本人点击本页现有操作。请求：本页明确对象ID/版本及必要字段；返回：本机内容或保存/恢复状态
- 本地 正式结果/报告：现有 当前仅独立report-sample-01与示意factor值；不存在真实result对象；计划 resultId/sessionId/reportVersion/contentVersion/scoringVersion/normVersion/factorValues/unknownFlags/qualityFlag/interpretationEvidence；本地计算、本地报告均候选未决；必须确定性可复现。若决定会员云保存，另定授权范围/留存/删除，不默认上传答案
- 本地 本次引用/来源快照：现有 id,kind,objectId,version,sectionId,title,excerpt,status,scope；计划 ownerSpaceId/sourceRef/objectRevision/selectedScope/executedSnapshot/revocationState；草稿引用可移除；正式发送先校验来源与版本；历史执行快照和当前可用状态分开；不自动读取全部历史
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-012, ZY-MEAS-006, ZY-NFR-010
- 验收ID：T-FR-012-N, T-FR-012-E1, T-FR-012-E2, T-MEAS-006, T-NFR-010-N
- 待决：D-02 16PF题源与授权（产品负责人，必要时由测量/法律/工程专业方协助）；D-03 AI重置版身份（产品负责人，必要时由测量/法律/工程专业方协助）；D-04 计分常模与适用性（产品负责人，必要时由测量/法律/工程专业方协助）

## 本机内容 · content

- 主线：随安装包题库→资格校验→离线可用
- 最小价值：知道安装时实际具备哪些合法题库与版本
- 前置：最新硬要求：所有发布题库默认随安装本地，不依赖首启下载；合法资格先决
- 出入与返回：data→content；返回原页，不改变当前session版本
- 当前边界：源码仍有历史按需下载表述；本页契约以默认安装本地为准。正版内容缺失不能假称全题库已提供
- 实际/计划状态：已随包3题示例, 正式未就绪, 计划更新失败或撤回

### 按钮与事件

- back · 我的数据：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- content.update.check [cloud] 仅后续更新能力启用且联网时；首启不依赖该调用。请求：已装版本,客户端能力版本（不含答案/私密画像）；返回：获准更新/撤回元数据；无更新仍用有效本地包
- 本地 题库/阅读/专题包：现有 D.questions{3个原创questionId,title,options}；D.topics{5个topicId,category,prompts}；D.report；D.factors；均随JS静态提供；计划 packId/contentVersion/assessmentId/questionId/optionId/licenseEvidence/eligibilityStatus/scoringVersion/normVersion/checksum；全部发布题库默认随安装本地；首启不依赖下载。资格不成立不分发正式内容；更新/撤回保留旧任务版本。更新服务如启用仅请求包和版本元数据
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-005, ZY-NFR-008, ZY-MEAS-001, ZY-OPS-001, ZY-ENG-001, ZY-ENG-010
- 验收ID：T-FR-005-N, T-FR-005-E1, T-FR-005-E2, T-FR-005-E3, T-NFR-008-N, T-MEAS-001, T-LEG-02, T-OPS-001, T-ENG-001, T-ENG-010, T-LEG-03, T-ENG-010-R3-MINIMUM, T-ENG-010-R3-TAMPER
- 待决：D-02 16PF题源与授权（产品负责人，必要时由测量/法律/工程专业方协助）；D-03 AI重置版身份（产品负责人，必要时由测量/法律/工程专业方协助）；D-04 计分常模与适用性（产品负责人，必要时由测量/法律/工程专业方协助）；D-05 首版完整价值切片（产品负责人，必要时由测量/法律/工程专业方协助）；D-06 AI供应商与数据用途（产品负责人，必要时由测量/法律/工程专业方协助）；D-08 空间、留存与备份（产品负责人，必要时由测量/法律/工程专业方协助）；D-11 平台与发布顺序（产品负责人，必要时由测量/法律/工程专业方协助）；D-14 设备与质量目标（产品负责人，必要时由测量/法律/工程专业方协助）；D-16 内容与支持运营（产品负责人，必要时由测量/法律/工程专业方协助）；D-17 每日选题与画像更新策略（产品负责人，必要时由测量/内容/工程专业方协助）；PAGE-ARCH-CANDIDATE 本地计算/本地报告/会员云保存（产品负责人和客户端/服务端工程，专业与隐私审校按需参与）

## 专题整理 · topic-workspace

- 主线：本人情况→保存认识→按需尝试/AI
- 最小价值：完成一份保留条件、依据和未知的本人整理
- 前置：有效topicId；新建无登录；旧记录归属与topic须一致
- 出入与返回：topic/records→workspace?topic&id；保存留本页；仅保存回records；尝试action-detail/引用assistant
- 当前边界：5套不同字段；工作与城市各7，关系/学习/独处各6；自由生活空间和通用决策上下文尚非完整能力
- 实际/计划状态：新建, 总览, 专注, 已存卡, 脏草稿, 旧版本, 空提交, 失败, 缺失

### 按钮与事件

- back · 返回：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 其他议题：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- v3-workspace-mode · 总览 / 专注：校验允许枚举后写本机偏好并局部刷新；人物family与theme分开；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- topic-save · 保存这份整理 / 保存这次修改：校topic/record；至少有一个非空字段；新建/保存修订历史并清草稿；无改动不新增revision；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- topic-edit · 先补信息：展开当前record-editor并聚焦第一字段；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- add-action · 选个小尝试：V2生成可改表单；专题需已保存版本；同文字同来源revision且active时复用；保存后action-detail；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 仅保存，回到我的记录 / 回到我的记录：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 回看这份整理的小尝试（1）：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- topic-to-assistant · 带着已保存的记录问助理：V2.attachSource去重/更新来源版本并填默认草稿→assistant；topic脏草稿须选已存版；文章固定quote-1非真实选段；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- delete-journal · 删除这份整理：确认后删记录/旧修订/草稿与新引用；关联action来源全文清掉但计划和观察保留；回records；当前真实出网=无；计划位置=undecided；同名操作语义保留；正式实现尚未接入/验证
- v3-step · 这次，想理清哪件具体的事 / 正在比较什么 / 最在意的两件事 / 暂时不能忽略的条件 / 决定前，还要弄清什么 / 有哪些亲历的事实或依据 / 我目前的认识或倾向 / 上一项 / 下一项 / 发生了哪件具体的事 / 当时，我需要什么 / 准备怎样表达一个请求 / 期待生活发生什么变化 / 家庭、工作与预算条件 / 还不了解什么 / 怎样先验证一小步 / 希望学习解决什么问题 / 能投入多少时间和精力 / 先用什么小实验验证 / 什么情况下想独处 / 独处前后有什么不同 / 接下来需要什么：按topic schema校index，仅workspaceSteps内存+焦点；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- submit-dialog · 保存到本机：调用当前dialogCallback；submit先trim且不能为空；confirm先关闭再执行；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- topic-action-saved · 使用已保存版本继续：V2生成可改表单；专题需已保存版本；同文字同来源revision且active时复用；保存后action-detail；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- topic-edit · 回到草稿，先保存修改：展开当前record-editor并聚焦第一字段；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- topic-edit · 回到草稿，先保存修改：展开当前record-editor并聚焦第一字段；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- topic-attach-saved · 使用已保存版本继续：V2.attachSource去重/更新来源版本并填默认草稿→assistant；topic脏草稿须选已存版；文章固定quote-1非真实选段；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- confirm-dialog · 删除这条记录：调用当前dialogCallback；submit先trim且不能为空；confirm先关闭再执行；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- topic-workspace.local-interaction [local] 页面进入、输入或本人点击本页现有操作。请求：本页明确对象ID/版本及必要字段；返回：本机内容或保存/恢复状态
- 本地 本人观察与专题整理：现有 id,kind,topicId,title,fields,text,revision,revisions{revision,fields,text,createdAt},sourceId,sourceKind,sectionId,createdAt,updatedAt；计划 ownerSpaceId/recordId/sourceRefs/currentRevision/explicitConsent；自述与测量事实分别标识；本人本机；历史修订保留；删除同时处理草稿与关联来源全文，已导出副本不可撤回
- 本地 编辑草稿/未保存选择：现有 editorDrafts{journal:id,topic:topicId:id,report:context,action-review:id}；pendingAnswer内存；V2.cachedDrafts/failedDrafts内存；计划 draftId/ownerSpaceId/objectId/baseRevision/updatedAt/saveStatus；本机；失败不清输入，迁移需独立预检；原型LocalStorage明文并非APP方案
- 本地 本次引用/来源快照：现有 id,kind,objectId,version,sectionId,title,excerpt,status,scope；计划 ownerSpaceId/sourceRef/objectRevision/selectedScope/executedSnapshot/revocationState；草稿引用可移除；正式发送先校验来源与版本；历史执行快照和当前可用状态分开；不自动读取全部历史
- 本地 小尝试与实际回看：现有 id,text,revision,status,sourceId,sourceKind,sourceVersion,sourceSnapshot,sectionId,reviews{id,outcome,text,actionText,actionRevision,createdAt},createdAt；计划 spaceId/actionId/reviewId/sourceRevision/reviewSubmitToken；本机本人决定；计划与实际观察独立；修改计划不改历史回看；提醒额外授权后才启用
- 本地 页面上下文：现有 route,params{id,topic,kind,tab},stack,scrolls,recordFilter,exploreCategory,exploreSearch,returnAfterAuth,checkoutReturn；计划 route/objectId/returnIntent/scrollAnchor；正文不进URL；本机UI上下文；内存与偏好保存边界由工程定；不需云端
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-017, ZY-FR-032, ZY-FR-033, ZY-LIFE-006, ZY-NFR-014, ZY-DATA-005
- 验收ID：T-FR-017-N, T-FR-017-E1, T-FR-017-E2, T-FR-032-N, T-FR-032-E1, T-FR-032-E2, T-FR-033-N, T-FR-033-E1, T-FR-033-E2, T-LIFE-006, T-LEG-01, T-NFR-014-N, T-DATA-005, T-LEG-07
- 待决：D-01 目标人群与边界（产品负责人，必要时由测量/法律/工程专业方协助）；D-04 计分常模与适用性（产品负责人，必要时由测量/法律/工程专业方协助）；D-05 首版完整价值切片（产品负责人，必要时由测量/法律/工程专业方协助）；D-08 空间、留存与备份（产品负责人，必要时由测量/法律/工程专业方协助）

## 尝试与观察 · action-detail

- 主线：计划→真实结果→再尝试/放下
- 最小价值：记录实际结果，不让计划冒充完成
- 前置：actionId有效，来源修订快照可追溯
- 出入与返回：actions/home/整理卡→detail?id；编辑弹层；返回来源或actions
- 当前边界：保存回看保留当时plan文字和revision；当前连续双保存缺少提交幂等门禁，正式APP必须补
- 实际/计划状态：active, reviewed, cancelled, 未尝试, 部分完成, 来源已删, 修订历史

### 按钮与事件

- nav · 回到小尝试 / 全部小尝试：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- back · 返回：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- edit-action · 修改：表单改text并revision++，不改reviews快照；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 回到这份整理：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- action-outcome · 还没尝试 / 有一点帮助 / 没看到变化 / 不太适合 / 只试了一部分：结果枚举写action-review:id草稿；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- save-action-review · 保存这次观察：校结果枚举，append回看含当时actionText/revision；not-yet仍active否则reviewed；清草稿；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- cancel-action · 这次先放下：cancel经确认置cancelled；restart置active；均保留reviews；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- restart-action · 重新放回当前尝试：cancel经确认置cancelled；restart置active；均保留reviews；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- submit-dialog · 保存到本机：调用当前dialogCallback；submit先trim且不能为空；confirm先关闭再执行；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- confirm-dialog · 先放下：调用当前dialogCallback；submit先trim且不能为空；confirm先关闭再执行；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- action-detail.local-interaction [local] 页面进入、输入或本人点击本页现有操作。请求：本页明确对象ID/版本及必要字段；返回：本机内容或保存/恢复状态
- 本地 小尝试与实际回看：现有 id,text,revision,status,sourceId,sourceKind,sourceVersion,sourceSnapshot,sectionId,reviews{id,outcome,text,actionText,actionRevision,createdAt},createdAt；计划 spaceId/actionId/reviewId/sourceRevision/reviewSubmitToken；本机本人决定；计划与实际观察独立；修改计划不改历史回看；提醒额外授权后才启用
- 本地 编辑草稿/未保存选择：现有 editorDrafts{journal:id,topic:topicId:id,report:context,action-review:id}；pendingAnswer内存；V2.cachedDrafts/failedDrafts内存；计划 draftId/ownerSpaceId/objectId/baseRevision/updatedAt/saveStatus；本机；失败不清输入，迁移需独立预检；原型LocalStorage明文并非APP方案
- 本地 本次引用/来源快照：现有 id,kind,objectId,version,sectionId,title,excerpt,status,scope；计划 ownerSpaceId/sourceRef/objectRevision/selectedScope/executedSnapshot/revocationState；草稿引用可移除；正式发送先校验来源与版本；历史执行快照和当前可用状态分开；不自动读取全部历史
- 本地 本人观察与专题整理：现有 id,kind,topicId,title,fields,text,revision,revisions{revision,fields,text,createdAt},sourceId,sourceKind,sectionId,createdAt,updatedAt；计划 ownerSpaceId/recordId/sourceRefs/currentRevision/explicitConsent；自述与测量事实分别标识；本人本机；历史修订保留；删除同时处理草稿与关联来源全文，已导出副本不可撤回
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 待修/待验：save-action-review在重复事件到来时仅以草稿当前状态校验，未见专用submission token；需正式幂等测试
- 取舍：优先复用本页现有子状态/说明弹层；导航、只读说明和局部调整不新建云API或后台实体
- 需求：ZY-FR-031, ZY-FR-035, ZY-LIFE-004, ZY-NFR-014
- 验收ID：T-FR-031-N, T-FR-031-E1, T-FR-031-E2, T-FR-035-N, T-FR-035-E1, T-FR-035-E2, T-LIFE-004, T-NFR-014-N
- 待决：D-05 首版完整价值切片（产品负责人，必要时由测量/法律/工程专业方协助）；D-06 AI供应商与数据用途（产品负责人，必要时由测量/法律/工程专业方协助）；D-15 用户价值与研究（产品负责人，必要时由测量/法律/工程专业方协助）

## 单因子测评 · single-factor

- 主线：16选1→固定题组→解释
- 最小价值：选一个因子进行独立探索
- 前置：正式单因子题组、许可、映射与计分依据齐备才能开始
- 出入与返回：home→single-factor；config/process/result同route；back回原入口
- 当前边界：仅内存选因子与原创布局选项；无持久答卷、正式题库、计分或AI
- 实际/计划状态：未选, 已选1, 布局作答, 结果空, 正式disabled

### 按钮与事件

- back · 认识：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- preview-factor · A 乐群 / B 推理 / C 情绪稳定 / E 支配 / F 活泼 / G 规则意识 / H 社交大胆 / I 敏感 / L 警觉 / M 抽象 / N 私密 / O 忧虑 / Q1 开放变化 / Q2 自立 / Q3 自律 / Q4 紧张：单因子选择/清除仅AssessmentPreview.factor内存；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- preview-stage · 查看所选因子的作答布局 / 查看结果区域 / 返回配置 / 返回作答布局：仅内存screen[route]=config/process/result并聚焦标题；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- preview-unavailable · 开始正式单因子测评：HTML disabled，没有dispatch分支；正式操作不可执行；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- preview-clear-factor · 清除选择：单因子选择/清除仅AssessmentPreview.factor内存；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- preview-answer · 先弄清楚具体要求 / 先想想自己的感受 / 看看情况，再决定：仅内存answer[route]=a/b/c；不persist；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- factor.session.begin [local] 正式资格通过且本人选定因子开始。请求：factorId,contentVersion,sessionIntent；返回：固定factorId/sessionId；评分位置另待定
- 本地 题库/阅读/专题包：现有 D.questions{3个原创questionId,title,options}；D.topics{5个topicId,category,prompts}；D.report；D.factors；均随JS静态提供；计划 packId/contentVersion/assessmentId/questionId/optionId/licenseEvidence/eligibilityStatus/scoringVersion/normVersion/checksum；全部发布题库默认随安装本地；首启不依赖下载。资格不成立不分发正式内容；更新/撤回保留旧任务版本。更新服务如启用仅请求包和版本元数据
- 本地 答卷：现有 id,kind,version,mode,status,index,answers{questionId:optionId},createdAt,updatedAt,updatedLabel,activeSession；计划 spaceId/sessionId/assessmentId/contentVersion/scoringVersion/answerRevision/saveState/submitToken/resultId?；本机个人空间；完成后只读快照；保留时长与清理策略待D-08，云副本不是默认
- 本地 假设配置：现有 旧App.simFactor/simValue内存；新AssessmentPreview.scores/count/factor/answer/screen内存；计划 simulationId/factorMap/scaleVersion/explicitlySetMask/sourceKind=hypothesis；当前刷新清空不入个人记录；正式是否保存独立假设待D-19；不得入本人测量/画像
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：收敛新旧因子/每日/模拟重复入口；config/process/result可用同route子状态；当前UI-only必须明示，不能为占位造假业务。旧simulation与新sandbox保留差异后再决定合并
- 需求：ZY-FR-014, ZY-FR-005, ZY-MEAS-001, ZY-NFR-007
- 验收ID：T-FR-014-N, T-FR-014-E1, T-FR-014-E2, T-FR-014-R1-SELECT, T-FR-005-N, T-FR-005-E1, T-FR-005-E2, T-FR-005-E3, T-MEAS-001, T-LEG-02, T-NFR-007-N
- 待决：D-02 16PF题源与授权（产品负责人，必要时由测量/法律/工程专业方协助）；D-03 AI重置版身份（产品负责人，必要时由测量/法律/工程专业方协助）；D-04 计分常模与适用性（产品负责人，必要时由测量/法律/工程专业方协助）

## 每日打卡 · daily-checkin

- 主线：运营题库→个人适配固定题组→回看
- 最小价值：每天3–5题，从未做适配题中观察自己
- 前置：默认安装本地的合资格运营题库；画像/历史使用范围由本人控制
- 出入与返回：home→daily-checkin；config/process/result同route；返回保留当天固定题组候选语义
- 当前边界：无真实daySet、画像、筛选、答卷或打卡记录；是否本地选题/画像更新及题库不足策略D-17未决
- 实际/计划状态：3, 4, 5题预览, 无题库, 过程, 结果空, 正式disabled

### 按钮与事件

- back · 认识：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- preview-count · 3 题 / 4 题 / 5 题：仅内存count在3/4/5中选择；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- preview-stage · 查看作答布局 / 查看结果区域 / 返回配置 / 返回作答布局：仅内存screen[route]=config/process/result并聚焦标题；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- preview-unavailable · 开始今日打卡：HTML disabled，没有dispatch分支；正式操作不可执行；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- preview-answer · 先弄清楚具体要求 / 先想想自己的感受 / 看看情况，再决定：仅内存answer[route]=a/b/c；不persist；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- daily.select [undecided] 每天第一次开始正式题组。请求：dayKey,本地题库版本,已做题标识,获准适配信息；返回：固定daySetId/题目ID/规则版本/不足原因；本地或云选题待D-17
- 本地 题库/阅读/专题包：现有 D.questions{3个原创questionId,title,options}；D.topics{5个topicId,category,prompts}；D.report；D.factors；均随JS静态提供；计划 packId/contentVersion/assessmentId/questionId/optionId/licenseEvidence/eligibilityStatus/scoringVersion/normVersion/checksum；全部发布题库默认随安装本地；首启不依赖下载。资格不成立不分发正式内容；更新/撤回保留旧任务版本。更新服务如启用仅请求包和版本元数据
- 本地 每日固定题组：现有 仅AssessmentPreview.count/screen/answer内存，无daySet；计划 daySetId/dayKey/timezone/contentVersion/selectedQuestionIds/selectionRuleVersion/completedIds/eligibilityInputs；每日首次固定且同天不换题；本地选题与画像更新位置/策略待D-17；题库默认安装本地
- 本地 答卷：现有 id,kind,version,mode,status,index,answers{questionId:optionId},createdAt,updatedAt,updatedLabel,activeSession；计划 spaceId/sessionId/assessmentId/contentVersion/scoringVersion/answerRevision/saveState/submitToken/resultId?；本机个人空间；完成后只读快照；保留时长与清理策略待D-08，云副本不是默认
- 本地 展示与隐私偏好：现有 name,avatar,avatarFamily,theme,density,fontSize,reduced,workspaceMode,chatRetention,memoryEnabled；不含真实画像；计划 settingsVersion/ownerScope/accessibilityOverrides/consentVersions；与推断画像分离；本机展示偏好；云同步若选用须明确字段；关闭留存只作用后续会话，不伪称删历史
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：收敛新旧因子/每日/模拟重复入口；config/process/result可用同route子状态；当前UI-only必须明示，不能为占位造假业务。旧simulation与新sandbox保留差异后再决定合并
- 需求：ZY-FR-015, ZY-FR-005, ZY-FR-026, ZY-DATA-002, ZY-ENG-001
- 验收ID：T-FR-015-N, T-FR-015-E1, T-FR-015-E2, T-FR-015-R1-RANGE, T-FR-015-R1-COLD, T-FR-015-R1-PROFILE, T-FR-015-R3-DAILY-1, T-FR-015-R3-DAILY-2, T-FR-015-R3-DAILY-3, T-FR-015-R3-QUESTION, T-FR-015-R3-DEVICES, T-FR-005-N, T-FR-005-E1, T-FR-005-E2, T-FR-005-E3, T-FR-026-N, T-FR-026-E1, T-FR-026-E2, T-FR-026-E3, T-FR-026-R1-SOURCE, T-DATA-002, T-LEG-05, T-ENG-001
- 待决：D-02 16PF题源与授权（产品负责人，必要时由测量/法律/工程专业方协助）；D-03 AI重置版身份（产品负责人，必要时由测量/法律/工程专业方协助）；D-04 计分常模与适用性（产品负责人，必要时由测量/法律/工程专业方协助）；D-05 首版完整价值切片（产品负责人，必要时由测量/法律/工程专业方协助）；D-06 AI供应商与数据用途（产品负责人，必要时由测量/法律/工程专业方协助）；D-08 空间、留存与备份（产品负责人，必要时由测量/法律/工程专业方协助）；D-14 设备与质量目标（产品负责人，必要时由测量/法律/工程专业方协助）；D-16 内容与支持运营（产品负责人，必要时由测量/法律/工程专业方协助）；D-17 每日选题与画像更新策略（产品负责人，必要时由测量/内容/工程专业方协助）；PAGE-ARCH-CANDIDATE 本地计算/本地报告/会员云保存（产品负责人和客户端/服务端工程，专业与隐私审校按需参与）

## 简化版16PF · short-16pf

- 主线：情境题→多因子映射→有限解释
- 最小价值：用少量复杂情境题探索性格角度
- 前置：内容、映射、计分及独立验证完成；不得等同标准测验
- 出入与返回：home→short-16pf；config/process/result同route
- 当前边界：题量未定；少题准确率无依据；当前原创1题布局不属于正式简化版题库
- 实际/计划状态：说明, 布局作答, 结果空, 正式disabled

### 按钮与事件

- back · 认识：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- preview-stage · 查看作答布局 / 查看结果区域 / 返回配置 / 返回作答布局：仅内存screen[route]=config/process/result并聚焦标题；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- preview-unavailable · 开始简化版探索：HTML disabled，没有dispatch分支；正式操作不可执行；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- preview-answer · 先弄清楚具体要求 / 先想想自己的感受 / 看看情况，再决定：仅内存answer[route]=a/b/c；不persist；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- short.session.begin [local] 独立内容资格通过后本人开始。请求：contentVersion,mappingVersion,sessionIntent；返回：固定session；不承诺标准16PF等效
- 本地 题库/阅读/专题包：现有 D.questions{3个原创questionId,title,options}；D.topics{5个topicId,category,prompts}；D.report；D.factors；均随JS静态提供；计划 packId/contentVersion/assessmentId/questionId/optionId/licenseEvidence/eligibilityStatus/scoringVersion/normVersion/checksum；全部发布题库默认随安装本地；首启不依赖下载。资格不成立不分发正式内容；更新/撤回保留旧任务版本。更新服务如启用仅请求包和版本元数据
- 本地 答卷：现有 id,kind,version,mode,status,index,answers{questionId:optionId},createdAt,updatedAt,updatedLabel,activeSession；计划 spaceId/sessionId/assessmentId/contentVersion/scoringVersion/answerRevision/saveState/submitToken/resultId?；本机个人空间；完成后只读快照；保留时长与清理策略待D-08，云副本不是默认
- 本地 正式结果/报告：现有 当前仅独立report-sample-01与示意factor值；不存在真实result对象；计划 resultId/sessionId/reportVersion/contentVersion/scoringVersion/normVersion/factorValues/unknownFlags/qualityFlag/interpretationEvidence；本地计算、本地报告均候选未决；必须确定性可复现。若决定会员云保存，另定授权范围/留存/删除，不默认上传答案
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：收敛新旧因子/每日/模拟重复入口；config/process/result可用同route子状态；当前UI-only必须明示，不能为占位造假业务。旧simulation与新sandbox保留差异后再决定合并
- 需求：ZY-FR-057, ZY-FR-004, ZY-MEAS-002, ZY-MEAS-004
- 验收ID：T-FR-057-N, T-FR-057-E1, T-FR-057-E2, T-FR-004-N, T-FR-004-E1, T-FR-004-E2, T-MEAS-002, T-MEAS-004
- 待决：D-02 16PF题源与授权（产品负责人，必要时由测量/法律/工程专业方协助）；D-03 AI重置版身份（产品负责人，必要时由测量/法律/工程专业方协助）；D-04 计分常模与适用性（产品负责人，必要时由测量/法律/工程专业方协助）；D-18 简化版内容映射与测量依据（产品负责人，必要时由测量/内容/工程专业方协助）

## 模拟性格 · personality-sandbox

- 主线：手设16因子→假设配置→可选AI
- 最小价值：展示假设性格，不记录为本人测量
- 前置：任何人可本地调整；若真实AI分析则须登录及共享额度
- 出入与返回：home→sandbox；config/result；旧simulation独立
- 当前边界：0–10仅UI尺度，默认中点未填写；内存刷新清空；不生成AI结论、不写画像
- 实际/计划状态：16项未设置, 部分, 全设, 配置结果, 分析disabled

### 按钮与事件

- back · 认识：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- preview-stage · 查看假设配置 / 继续调整假设：仅内存screen[route]=config/process/result并聚焦标题；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- preview-clear-scores · 清空全部假设值：清空16项假设内存scores，刷新重绘；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- preview-unavailable · 分析假设性格：HTML disabled，没有dispatch分支；正式操作不可执行；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- hypothesis.analyze [cloud] 若未来启用AI，登录/额度/假设标识/外发确认后。请求：logicalRequestId,sourceKind=hypothesis,factorMap,scaleVersion；返回：假设解读与依据/限制，不能更新本人画像
- 本地 假设配置：现有 旧App.simFactor/simValue内存；新AssessmentPreview.scores/count/factor/answer/screen内存；计划 simulationId/factorMap/scaleVersion/explicitlySetMask/sourceKind=hypothesis；当前刷新清空不入个人记录；正式是否保存独立假设待D-19；不得入本人测量/画像
- 本地 AI用量账本：现有 used,usageDay,usage{id,kind,status,createdAt}；全部本机演示可绕过；计划 accountId/dayKey/logicalRequestId/kind/settlementState/quotaPolicyVersion/used/remaining；真实额度云端按账号跨设备统一；访客0，登录非会员分析+chat合计10/日；升级、到期、退款不重置已用量；日界线和失败/停止结算D-07未决
- 本地 本次引用/来源快照：现有 id,kind,objectId,version,sectionId,title,excerpt,status,scope；计划 ownerSpaceId/sourceRef/objectRevision/selectedScope/executedSnapshot/revocationState；草稿引用可移除；正式发送先校验来源与版本；历史执行快照和当前可用状态分开；不自动读取全部历史
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：收敛新旧因子/每日/模拟重复入口；config/process/result可用同route子状态；当前UI-only必须明示，不能为占位造假业务。旧simulation与新sandbox保留差异后再决定合并
- 需求：ZY-FR-016, ZY-FR-023, ZY-AI-001, ZY-NFR-007
- 验收ID：T-FR-016-N, T-FR-016-E1, T-FR-016-E2, T-FR-016-R1-SIM, T-FR-023-N, T-FR-023-E1, T-FR-023-E2, T-FR-023-E3, T-FR-023-R2-SHARED, T-FR-023-R3-DAILYAI-1, T-FR-023-R3-DAILYAI-2, T-FR-023-R3-DAILYAI-3, T-FR-023-R3-DAILYAI-4, T-AI-001, T-NFR-007-N
- 待决：D-02 16PF题源与授权（产品负责人，必要时由测量/法律/工程专业方协助）；D-03 AI重置版身份（产品负责人，必要时由测量/法律/工程专业方协助）；D-04 计分常模与适用性（产品负责人，必要时由测量/法律/工程专业方协助）；D-05 首版完整价值切片（产品负责人，必要时由测量/法律/工程专业方协助）；D-06 AI供应商与数据用途（产品负责人，必要时由测量/法律/工程专业方协助）；D-07 共享次数与计量（产品负责人，必要时由测量/法律/工程专业方协助）；D-13 安全与专业审校（产品负责人，必要时由测量/法律/工程专业方协助）；D-17 每日选题与画像更新策略（产品负责人，必要时由测量/内容/工程专业方协助）；D-19 模拟性格量尺与假设分析（产品负责人，必要时由测量/内容/工程专业方协助）；D-21 账号关联与防重复领额度（产品负责人，开发接入时与工程核验）

## AI重置版 · ai-reset

- 主线：独立内容家族→资格门禁→探索
- 最小价值：了解与原版并列的新路线边界
- 前置：题源、改编许可、计分与独立验证未满足则不可启动
- 出入与返回：home→ai-reset→home
- 当前边界：不是点击后临时让AI编题的既定方案；内容生产与运行方式未决；同级不等于等效
- 实际/计划状态：当前不可开始；计划有效包, 撤回, 不适用

### 按钮与事件

- back · 认识：优先真实浏览历史；无历史按当前route归root；未保存答案阻断；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- preview-unavailable · 开始AI重置版：HTML disabled，没有dispatch分支；正式操作不可执行；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证
- nav · 返回认识：App.nav按data-route/id/topic/kind/tab跳转；记录filter先保存；usage特殊为弹层；当前真实出网=无；计划位置=local；同名操作语义保留；正式实现尚未接入/验证

### API与数据

- ai-reset.local-interaction [local] 页面进入、输入或本人点击本页现有操作。请求：本页明确对象ID/版本及必要字段；返回：本机内容或保存/恢复状态
- 本地 题库/阅读/专题包：现有 D.questions{3个原创questionId,title,options}；D.topics{5个topicId,category,prompts}；D.report；D.factors；均随JS静态提供；计划 packId/contentVersion/assessmentId/questionId/optionId/licenseEvidence/eligibilityStatus/scoringVersion/normVersion/checksum；全部发布题库默认随安装本地；首启不依赖下载。资格不成立不分发正式内容；更新/撤回保留旧任务版本。更新服务如启用仅请求包和版本元数据
- 本地 答卷：现有 id,kind,version,mode,status,index,answers{questionId:optionId},createdAt,updatedAt,updatedLabel,activeSession；计划 spaceId/sessionId/assessmentId/contentVersion/scoringVersion/answerRevision/saveState/submitToken/resultId?；本机个人空间；完成后只读快照；保留时长与清理策略待D-08，云副本不是默认
- 本地 正式结果/报告：现有 当前仅独立report-sample-01与示意factor值；不存在真实result对象；计划 resultId/sessionId/reportVersion/contentVersion/scoringVersion/normVersion/factorValues/unknownFlags/qualityFlag/interpretationEvidence；本地计算、本地报告均候选未决；必须确定性可复现。若决定会员云保存，另定授权范围/留存/删除，不默认上传答案
- 云端现状：无真实云端服务/数据写入；本机模拟不得称云已存
- 失败：留当前输入/引用/原对象；pending保存态不能冒充成功；重试同对象或导出临时恢复文件；仅适用未来云操作：保留logicalRequestId/orderId/feedbackId；先查同任务，未知不自动重建
- 取舍：收敛新旧因子/每日/模拟重复入口；config/process/result可用同route子状态；当前UI-only必须明示，不能为占位造假业务。旧simulation与新sandbox保留差异后再决定合并
- 需求：ZY-FR-002, ZY-MEAS-002, ZY-FR-004, ZY-NFR-008
- 验收ID：T-FR-002-N, T-FR-002-E1, T-FR-002-E2, T-FR-002-R1-ENTRY, T-MEAS-002, T-FR-004-N, T-FR-004-E1, T-FR-004-E2, T-NFR-008-N
- 待决：D-02 16PF题源与授权（产品负责人，必要时由测量/法律/工程专业方协助）；D-03 AI重置版身份（产品负责人，必要时由测量/法律/工程专业方协助）；D-04 计分常模与适用性（产品负责人，必要时由测量/法律/工程专业方协助）

# 有意义但尚未补齐的设计条款

以下只合入现有页，不因数量制造新页，也不声称当前已实现。

- HIST-GAP-01 认识变化的时间线 → records：records按时间排序/必要日期筛选，原来源和行动可回看；不恢复独立时间线页面
- HIST-GAP-02 每日观察回看 → daily-checkin, records：records增加每日分类和指定日期/题组详情，同一daily-checkin结果模式回看
- HIST-GAP-05 此刻的状态与感受 → journal, question, report：开始/完成或报告内提供可跳过一句状态记录，绑定原session/result；无需独立情绪量表
- HIST-GAP-06 一条认识的来由 → journal, portrait：portrait选中认识后展开来源与适用情境
- HIST-GAP-07 补充我的情境 → journal, portrait：在原认识旁写补充/符合度和用途，保留来源且不改测评分数
- HIST-GAP-08 这条信息的来源 → conversation, memories, records：记忆卡提供原文/原对象入口和失效状态；不增来源包装页
- HIST-GAP-09 记忆的更改记录 → memories：记忆内展开修订历史，保留旧内容/时间/原因；不建复杂版本管理平台
- HIST-GAP-10 我希望怎样交流 → settings：settings一组简短偏好即可；不堆“人格化助理”额外功能
- HIST-GAP-11 不同情境中的我 → journal, portrait, records：观察保留可选情境，画像相关认识中并列相应来源
- HIST-GAP-12 我们知道什么，还缺什么 → journal, portrait：在相关认识标未知与原因，允许暂不补充；按需要就近进入观察
- HIST-GAP-13 把不同说法放在一起 → journal, portrait：原认识展开并列依据，选择两种都成立/纠正旧说法/暂未知并留下说明
- HIST-GAP-14 让一个优势用在生活里 → action-detail, actions：action编辑里按需要保留来源、要尝试什么、观察什么及可选代价，不建额外实验系统
- HIST-GAP-15 个人信息 → me：只保留称呼；交流偏好移settings；背景在实际任务中按需自愿说明，不恢复通用个人资料长表

# 弹层输入与提交边界

textarea#dialog-field当前上限1500；称呼实际保存截取20。提交trim后不能为空，callback返回false时留弹层；成功才关闭。取消/关闭/Escape丢弃仅DOM未提交输入，没有自动草稿。confirm-dialog另为先关后执行，不能当异步失败已保留。

- me / edit-name / profile.name：称呼；初值=state.name；App.form callback commit(s=>s.name=trimmedText.slice(0,20))；当前最多保留20字符，与textarea1500上限不同
- report / add-action / action.text：什么情况下，试着做什么？；初值=report按work/relationship给预写起点；topic-workspace为空且须已存record；其他入口按实际V2.createAction逻辑；同active text+sourceId+sourceVersion复用；否则commit新建action含revision1/来源快照/空reviews，导航action-detail
- conversation / add-action / action.text：什么情况下，试着做什么？；初值=report按work/relationship给预写起点；topic-workspace为空且须已存record；其他入口按实际V2.createAction逻辑；同active text+sourceId+sourceVersion复用；否则commit新建action含revision1/来源快照/空reviews，导航action-detail
- conversation / candidate-memory / memory.candidate.text：可修改的候选内容；初值=预写建议“我想观察：准备时间是否影响我表达的清晰程度。”，不是AI推断；只有memoryEnabled且来源有效、非sample-report时打开；commit新建candidate，保存来源会话/消息ID；仍需另行确认采用
- memories / edit-memory / memory.text：内容；初值=按memoryId读取m.text；commit更新text，revision+1，status回candidate；不保存旧版全文历史
- actions / new-action / action.text：什么情况下，试着做什么？；初值=空字符串；V2.createAction；用户填后同源同文防重或新增action→action-detail
- support / design-feedback / feedbackText：页面 / 问题 / 希望发生什么；初值=空字符串；download(jianji-design-feedback.txt,text,text/plain)后返回true并关闭；只交给浏览器，不证明文件已保存/客服受理
- topic-workspace / add-action / action.text：什么情况下，试着做什么？；初值=report按work/relationship给预写起点；topic-workspace为空且须已存record；其他入口按实际V2.createAction逻辑；同active text+sourceId+sourceVersion复用；否则commit新建action含revision1/来源快照/空reviews，导航action-detail
- topic-workspace / topic-action-saved / action.text：什么情况下，试着做什么？；初值=空字符串；采用原整理已存revision；V2.createAction(savedConfirmed=true)，来源快照为已保存note版本，不把脏草稿默默采用
- action-detail / edit-action / action.text：打算怎样试？；初值=按actionId读取a.text；commit写text并revision+1，不修改已有reviews中的actionText/actionRevision

# 交付与验证边界

固定源码commit的只读静态核对和146个代表性合成render成功；没有改站、部署或调用真实AI/身份/支付服务。按钮真实出网全部为无，plannedLocation独立标计划。验收ID只是相关待执行用例，不能当按钮级已通过记录。
