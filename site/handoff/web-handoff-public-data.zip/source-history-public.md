# 原始页面职责与动作逐项对账及价值裁决

保留有价值的能力与必要正常/异常流程，删除重复入口和无场景扩展。39 route不是删功能证据；119历史职责有映射也不是完成证明。以逐项价值裁决决定保留/合并/删除，而不是恢复旧页数。

## 1. 先说结论

旧版119职责（107独立页+12页内模块）、551显式动作和22后台职责/66动作全部可追溯。当前是39真实route、77页面/功能节点、14场景、8后台域，共99目录节点。

最新价值裁决：保留 14项；合并 96项；删除 8项；待确认 1项。这些是职责处置数，不是要建设的独立页面数。

其中15项在当前设计承载中没有等量能力；经价值过滤，2项应删除，不补回，其余也优先并入现有任务。历史缺口绝不自动成为恢复清单。

## 2. 明确删除，避免过度延伸

- **分享记录与控制（share-records）**：当前仅做文件/朋友圈分享；独立在线链接管理入口缺少已确认场景，暂不扩张托管系统。 保留必要价值：当前删除独立入口，保留范围预览、脱敏与文件不可撤回说明；若未来确认在线分享，访问权限、撤回/失效和范围管理义务必须同批补齐，不能据本裁决免除
- **模拟组合起点（simulation-presets）**：用户明确手设16因子；随机人格和预设素材没有已证明价值，容易把标签娱乐扩展成第二产品。 保留必要价值：保留手设16因子、重置、假设标记和必要结果说明
- **换几个角度认识自己（exploration-perspectives）**：已有现实问题探索目录、概念阅读和画像，无需再造一个“多角度认识自己”导航大厅。 保留必要价值：相关角度在现实专题或有依据画像中就近呈现
- **后续协作能力（skills-list）**：泛化技能目录尚无具体任务、真实接入或明确产物，容易变为无场景能力大厅。 保留必要价值：有明确高价值任务时再作为该任务中的操作，不保留空技能平台
- **一种协作方法（skill-detail）**：无具体可用技能时单独详情与输出样稿造成虚假可用和额外跳转。 保留必要价值：具体方法说明就近放在原任务，不建立通用技能详情系统
- **我持续关心的问题（life-space-list）**：通用长期问题空间包含建档、搜索、归集、归档，当前与专题整理/观察/小尝试重复且明显延伸。 保留必要价值：保留五类现实专题整理和本人记录；不新增第二套问题空间管理
- **围绕一个生活问题（life-space-detail）**：无独立且不可由专题整理满足的场景，不保留通用“生活空间”容器。 保留必要价值：现状、依据、未知、下一步保留在topic-workspace及小尝试，引用同一对象
- **形象编辑方案（avatar-editor）**：部件捏脸对自我理解主线无直接贡献，素材/组合/预览成本高；现有人物预设已满足更换外观。 保留必要价值：保留已确认的详细人物、预设切换及主题独立；不扩部件编辑器

## 3. 真正有价值的最小补齐

- **P1 · 认识变化的时间线（record-timeline）**：records按时间排序/必要日期筛选，原来源和行动可回看；不恢复独立时间线页面
- **P1 · 每日观察回看（daily-review）**：records增加每日分类和指定日期/题组详情，同一daily-checkin结果模式回看
- **P1 · 此刻的状态与感受（session-checkin）**：开始/完成或报告内提供可跳过一句状态记录，绑定原session/result；无需独立情绪量表
- **P1 · 一条认识的来由（portrait-insight）**：portrait选中认识后展开来源与适用情境
- **P1 · 补充我的情境（portrait-reflection）**：在原认识旁写补充/符合度和用途，保留来源且不改测评分数
- **P0 · 这条信息的来源（memory-source）**：记忆卡提供原文/原对象入口和失效状态；不增来源包装页
- **P0 · 记忆的更改记录（memory-changes）**：记忆内展开修订历史，保留旧内容/时间/原因；不建复杂版本管理平台
- **P1 · 我希望怎样交流（ai-settings）**：settings一组简短偏好即可；不堆“人格化助理”额外功能
- **P1 · 不同情境中的我（situational-self）**：观察保留可选情境，画像相关认识中并列相应来源
- **P1 · 我们知道什么，还缺什么（understanding-gaps）**：在相关认识标未知与原因，允许暂不补充；按需要就近进入观察
- **P1 · 把不同说法放在一起（insight-reconcile）**：原认识展开并列依据，选择两种都成立/纠正旧说法/暂未知并留下说明
- **P1 · 让一个优势用在生活里（strength-experiment）**：action编辑里按需要保留来源、要尝试什么、观察什么及可选代价，不建额外实验系统
- **P1 · 个人信息（profile-edit）**：只保留称呼；交流偏好移settings；背景在实际任务中按需自愿说明，不恢复通用个人资料长表

另必须注意：关闭“允许提出记忆候选”不等于暂停使用已有记忆。真实导入只支持空空间复制，不等于非空备份合并冲突已实现；微信/支付宝优先登录、首次无关联建号、短信绑定手机号及手机号备选，还有支付/朋友圈/防刷，全部按最新指示仅记录待开发，不能算删除。

## 4. 数量来源，不能混算

- **119 = 107 + 12**：2026-10-01全页面结构版，119职责/107独立页/12页内模块；源码重算与原README一致。（已核对历史资料；公开证据摘要见JSON）
- **574 → 551**：三份领域数据声明574动作；structure.js去掉已取消图形切换/重复入口后551，和refined-routes的551键集合完全一致。（已核对历史资料；公开证据摘要见JSON）
- **703 / 725**：原文不同批次声称的运行时补充操作计数，含公共导航/图形等；不是551显式动作同口径，本轮未重新运行旧设计台证明这两个数。（已核对历史资料；公开证据摘要见JSON）
- **100 = 96 + 4；88逻辑路由**：更早2026-05-21旧小程序工作区的100物理注册页，96页面/弹层/模板节点+4题库占位页；不能当当前产品完整能力或历史已验收数量。（已核对历史资料；公开证据摘要见JSON）
- **65 → 42 → 39**：65旧建议承载、42新任务承载、39当前真实route属于不同版本和统计对象；不是119项功能删到39项。（已核对历史资料；公开证据摘要见JSON）

“最初100多页”尚未唯一绑定版本；最直接对应完整设计台的是119职责，更早旧小程序确有100物理页另一批。

## 5. 119职责逐项价值裁决与去向

| 原ID / 名称 | 价值裁决 | 当前/建议承载 | 理由与最小处理 | 现状判定 |
|---|---|---|---|
| home / 首页 | 保留 | home → home；ai-reset → ai-reset；single-factor → single-factor；daily-checkin → daily-checkin；short-16pf → short-16pf；personality-sandbox → personality-sandbox | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 保留 |
| explore / 探索 | 合并 | explore → explore | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| topic-list / 生活议题 | 合并 | explore → explore | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| assessment-search / 寻找题组 | 合并 | explore → explore | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| assessment-detail / 测评详情 | 合并 | assessment-detail → topic?id=work-choice | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| assessment-source / 题源与解释依据 | 合并 | assessment-detail → topic?id=work-choice；content → content；report-source → report?id=report-sample-01；ai-reset → ai-reset | 题源/资格/使用边界不可丢；没必要强制先跳一页。 详情内可展开，长文需要专注阅读时再独立 | 尚未设计 |
| assessment-versions / 版本与适用范围 | 合并 | assessment-detail → topic?id=work-choice；content → content；report-source → report?id=report-sample-01；ai-reset → ai-reset | 不同内容/计分版本必须可辨，旧记录须锁原版。 开始区查看资格并选择新版本，版本比较就近展开 | 尚未设计 |
| content-library / 本地内容包 | 合并 | content → content | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 只为后续内容更新或可选重新修复补校验、取消、版本替换/撤回影响和旧包恢复状态；不得恢复必经获取题包页，也不得改写旧答卷结果 | 尚未设计 |
| content-download / 获取内容包 | 合并 | content → content | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 只为后续内容更新或可选重新修复补校验、取消、版本替换/撤回影响和旧包恢复状态；不得恢复必经获取题包页，也不得改写旧答卷结果 | 尚未设计 |
| content-updates / 内容更新说明 | 合并 | content → content | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 只为后续内容更新或可选重新修复补校验、取消、版本替换/撤回影响和旧包恢复状态；不得恢复必经获取题包页，也不得改写旧答卷结果 | 尚未设计 |
| session-prepare / 开始之前 | 合并 | home → home；assessment-detail → topic?id=work-choice；question → question?id=session-demo-seed | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| question / 专注答题 | 保留 | question → question?id=session-demo-seed；save-failure-flow → question?id=session-demo-seed | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 保留 |
| answer-review / 检查这次作答 | 合并 | review → review?id=session-demo-seed；complete → complete?id=session-demo-seed | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| assessment-submit / 提交与生成结果 | 合并 | review → review?id=session-demo-seed；complete → complete?id=session-demo-seed | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| session-recovery / 恢复未完成测评 | 合并 | home → home；records → records；question → question?id=session-demo-seed；recovery → 规格/记录；save-failure-flow → question?id=session-demo-seed | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| unfinished / 未完成的探索 | 合并 | home → home；records → records；question → question?id=session-demo-seed；recovery → 规格/记录；save-failure-flow → question?id=session-demo-seed | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| report / 我的探索报告 | 保留 | report → report?id=report-sample-01；report-source → report?id=report-sample-01 | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 保留 |
| factor-detail / 理解一个因子 | 合并 | report → report?id=report-sample-01；report-source → report?id=report-sample-01 | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| report-evidence / 这份认识从哪里来 | 合并 | report → report?id=report-sample-01；report-source → report?id=report-sample-01 | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| report-feedback / 补充我的真实经历 | 合并 | report → report?id=report-sample-01；report-source → report?id=report-sample-01 | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| report-explanation / 完整解释与相处建议 | 合并 | report → report?id=report-sample-01；report-source → report?id=report-sample-01 | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| records / 测评记录 | 合并 | records → records；journal → journal；workspace-saved → topic-workspace?topic=work-choice&id=topic-note-demo-v2 | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| record-timeline / 认识变化的时间线 | 合并 | records → records | 按时间找回旧记录有价值，独立可视化成长时间线无必要。 records按时间排序/必要日期筛选，原来源和行动可回看；不恢复独立时间线页面 | 真实遗漏 |
| compare-select / 选择可比较的记录 | 合并 | compare → compare | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 缺两份对象选择、可比性核对结果、仅并列/允许差值两类结果布局；不要伪造可比分数 | 尚未设计 |
| compare-report / 两次探索怎样看 | 合并 | compare → compare | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 缺两份对象选择、可比性核对结果、仅并列/允许差值两类结果布局；不要伪造可比分数 | 尚未设计 |
| share-preview / 分享前先看看 | 合并 | share → share | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| share-records / 分享记录与控制 | 删除 | share → share | 当前仅做文件/朋友圈分享；独立在线链接管理入口缺少已确认场景，暂不扩张托管系统。 不补回该旧页面或系统。当前删除独立入口，保留范围预览、脱敏与文件不可撤回说明；若未来确认在线分享，访问权限、撤回/失效和范围管理义务必须同批补齐，不能据本裁决免除 | 尚未设计 |
| single-factor-list / 先了解一个角度 | 合并 | single-factor → single-factor；single-factor-process → single-factor；single-factor-result → single-factor；factor-library → explore | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| single-factor-detail / 单因子探索说明 | 合并 | single-factor → single-factor；single-factor-process → single-factor；single-factor-result → single-factor；factor-library → explore | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| daily / 每日随机探索 | 合并 | daily-checkin → daily-checkin；daily-checkin-process → daily-checkin；daily-checkin-result → daily-checkin | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| daily-review / 每日观察回看 | 合并 | daily-checkin-result → daily-checkin；records → records | 每日固定题组需要找回当天问题与本人作答；普通自由观察不能替代。 records增加每日分类和指定日期/题组详情，同一daily-checkin结果模式回看 | 真实遗漏 |
| light-intro / 轻量探索 | 待确认 | short-16pf → short-16pf；short-16pf-process → short-16pf；short-16pf-result → short-16pf；light-suite → simulation | 旧轻量题组不一定等同最新简化版16PF，不能为了少页面把不同测量身份合并。 先核对是否还有非16PF轻量题组；若没有，删除旧泛化轻量入口，保留最新简化16PF | 无法确认 |
| simulation / 模拟一种人格组合 | 合并 | personality-sandbox → personality-sandbox；personality-sandbox-result → personality-sandbox；light-suite → simulation | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| simulation-presets / 模拟组合起点 | 删除 | personality-sandbox → personality-sandbox | 用户明确手设16因子；随机人格和预设素材没有已证明价值，容易把标签娱乐扩展成第二产品。 不补回该旧页面或系统。保留手设16因子、重置、假设标记和必要结果说明 | 真实遗漏 |
| simulation-result / 假设组合的观察 | 合并 | personality-sandbox → personality-sandbox；personality-sandbox-result → personality-sandbox；light-suite → simulation | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| assessment-favorites / 想以后探索的题组 | 合并 | explore → explore | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| personality-guide / 先读懂这些概念 | 合并 | article → article?id=read-traits；factor-library → explore | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| exploration-perspectives / 换几个角度认识自己 | 删除 | article → article?id=read-traits；explore → explore；portrait → portrait | 已有现实问题探索目录、概念阅读和画像，无需再造一个“多角度认识自己”导航大厅。 不补回该旧页面或系统。相关角度在现实专题或有依据画像中就近呈现 | 真实遗漏 |
| decision-context / 梳理这次的现实问题 | 合并 | topic-workspace → topic-workspace?topic=work-choice；journal → journal | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| session-checkin / 此刻的状态与感受 | 合并 | question → question?id=session-demo-seed；report → report?id=report-sample-01；journal → journal | 需要解释特定作答前后情境时有用，默认不增加一页和必填。 开始/完成或报告内提供可跳过一句状态记录，绑定原session/result；无需独立情绪量表 | 真实遗漏 |
| knowledge-detail / 性格解释应该怎样读 | 合并 | article → article?id=read-traits；factor-library → explore | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| assistant / 个人助理 | 保留 | assistant → assistant；context → assistant；usage → assistant | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 保留 |
| conversation-list / 过去聊过的 | 保留 | conversations → conversations | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 保留 |
| conversation-detail / 连续对话 | 保留 | conversation → conversation?id=conversation-demo-history；context → assistant；usage → assistant；memory-flow → memories | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 保留 |
| conversation-settings / 这段对话 | 合并 | conversation → conversation?id=conversation-demo-history | 删除/必要会话控制有价值，额外每会话大设置表负担高。 原对话内保留必要控制，其余偏好共享settings | 合并 |
| context-select / 选择本次依据 | 合并 | context → assistant；conversation → conversation?id=conversation-demo-history | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| context-preview / 本次会参考什么 | 合并 | context → assistant；conversation → conversation?id=conversation-demo-history | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| ai-quota / AI共用次数 | 合并 | usage → assistant；conversation → conversation?id=conversation-demo-history | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| ai-usage-history / AI使用记录 | 合并 | usage → assistant；conversation → conversation?id=conversation-demo-history | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| my-portrait / 我正在了解的自己 | 保留 | portrait → portrait | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 保留 |
| portrait-insight / 一条认识的来由 | 合并 | portrait → portrait；journal → journal | 逐条认识必须可解释、可质疑；无需独立层层详情。 portrait选中认识后展开来源与适用情境 | 真实遗漏 |
| portrait-reflection / 补充我的情境 | 合并 | portrait → portrait；journal → journal | 用户能够纠正不符合经历的认识是核心。 在原认识旁写补充/符合度和用途，保留来源且不改测评分数 | 真实遗漏 |
| memory-list / 助理记住了什么 | 合并 | memories → memories；memory-flow → memories | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| memory-detail / 一条记忆 | 合并 | memories → memories；memory-flow → memories | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| memory-inbox / 这些值得记住吗 | 合并 | memories → memories；memory-flow → memories | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| memory-edit / 编辑一条记忆 | 合并 | memories → memories；memory-flow → memories | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| memory-source / 这条信息的来源 | 合并 | memories → memories；conversation → conversation?id=conversation-demo-history；records → records | 记忆的采用必须可追溯，来源缺失要明示。 记忆卡提供原文/原对象入口和失效状态；不增来源包装页 | 真实遗漏 |
| memory-controls / 记忆怎样使用 | 合并 | privacy → privacy；memories → memories | 提出候选与采用已有记忆是两个不同权限，不能混在一个开关。 隐私页分别提供候选控制与暂停已有长期记忆引用，不新增控制中心 | 合并 |
| memory-changes / 记忆的更改记录 | 合并 | memories → memories | 纠正后不能丢原义和来源，最小修订记录有价值。 记忆内展开修订历史，保留旧内容/时间/原因；不建复杂版本管理平台 | 真实遗漏 |
| action-list / 我想试试的事 | 保留 | actions → actions；action-detail → action-detail?id=action-demo-v2 | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 保留 |
| action-detail / 一个小尝试 | 合并 | action-detail → action-detail?id=action-demo-v2；action-observed → action-detail?id=action-demo-v2；actions → actions | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| action-edit / 安排一个小尝试 | 合并 | action-detail → action-detail?id=action-demo-v2；action-observed → action-detail?id=action-demo-v2；actions → actions | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| observation-edit / 记下一点观察 | 保留 | journal → journal | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 保留 |
| observation-history / 我的观察与变化 | 合并 | records → records；journal → journal；workspace-saved → topic-workspace?topic=work-choice&id=topic-note-demo-v2 | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| action-review / 回看这次尝试 | 合并 | action-detail → action-detail?id=action-demo-v2；action-observed → action-detail?id=action-demo-v2；actions → actions | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| ai-settings / 我希望怎样交流 | 合并 | settings → settings | 基本交流长度与澄清/建议方式有直接价值。 settings一组简短偏好即可；不堆“人格化助理”额外功能 | 真实遗漏 |
| skills-list / 后续协作能力 | 删除 | skills → 规格/记录 | 泛化技能目录尚无具体任务、真实接入或明确产物，容易变为无场景能力大厅。 不补回该旧页面或系统。有明确高价值任务时再作为该任务中的操作，不保留空技能平台 | 尚未设计 |
| skill-detail / 一种协作方法 | 删除 | skills → 规格/记录 | 无具体可用技能时单独详情与输出样稿造成虚假可用和额外跳转。 不补回该旧页面或系统。具体方法说明就近放在原任务，不建立通用技能详情系统 | 尚未设计 |
| reminder-settings / 回看提醒方案 | 合并 | reminders → 规格/记录 | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 无提醒对象、时间/时区、关闭及拒绝权限状态布局；此处后置不影响手动观察 | 尚未设计 |
| life-space-list / 我持续关心的问题 | 删除 | life-spaces → 规格/记录；topic-workspace → topic-workspace?topic=work-choice | 通用长期问题空间包含建档、搜索、归集、归档，当前与专题整理/观察/小尝试重复且明显延伸。 不补回该旧页面或系统。保留五类现实专题整理和本人记录；不新增第二套问题空间管理 | 尚未设计 |
| life-space-detail / 围绕一个生活问题 | 删除 | life-spaces → 规格/记录；topic-workspace → topic-workspace?topic=work-choice | 无独立且不可由专题整理满足的场景，不保留通用“生活空间”容器。 不补回该旧页面或系统。现状、依据、未知、下一步保留在topic-workspace及小尝试，引用同一对象 | 尚未设计 |
| situational-self / 不同情境中的我 | 合并 | portrait → portrait；journal → journal；records → records | 情境差异属于核心理解，不需要另一套情境卡系统。 观察保留可选情境，画像相关认识中并列相应来源 | 真实遗漏 |
| understanding-gaps / 我们知道什么，还缺什么 | 合并 | portrait → portrait；journal → journal | 承认未知是必要可信边界，不需要独立网格收集/填满人格图。 在相关认识标未知与原因，允许暂不补充；按需要就近进入观察 | 真实遗漏 |
| insight-reconcile / 把不同说法放在一起 | 合并 | portrait → portrait；journal → journal | 区分来源与情境、保留相反证据有价值；不用独立复杂矛盾处理中心。 原认识展开并列依据，选择两种都成立/纠正旧说法/暂未知并留下说明 | 真实遗漏 |
| strength-experiment / 让一个优势用在生活里 | 合并 | actions → actions；action-detail → action-detail?id=action-demo-v2 | 有依据的小尝试与观察价值保留；独立优势实验系统重复action生命周期。 action编辑里按需要保留来源、要尝试什么、观察什么及可选代价，不建额外实验系统 | 真实遗漏 |
| ai-analysis / AI分析 | 合并 | analysis → 规格/记录；context → assistant；usage → assistant | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 需分析确认→生成/停止→同任务查询→结果证据/纠正/记忆/行动/再次分析整条布局。对话不等于独立分析结果 | 尚未设计 |
| ai-analysis-result / AI分析结果 | 合并 | analysis → 规格/记录；context → assistant；usage → assistant | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 需分析确认→生成/停止→同任务查询→结果证据/纠正/记忆/行动/再次分析整条布局。对话不等于独立分析结果 | 尚未设计 |
| profile / 我的 | 保留 | me → me | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 保留 |
| welcome / 从认识自己开始 | 合并 | home → home；support → support；privacy → privacy | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| login / 登录 | 合并 | auth → auth；login-requirement → 规格/记录；phone-requirement → 规格/记录 | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 尚未设计第三方登录/首次无关联建号/短信绑定手机号/手机号备选及取消、验证失败状态；全部按用户要求仅记录待开发，不计为被删除，也不擅自新增UI | 尚未设计 |
| register / 创建账号 | 合并 | auth → auth；login-requirement → 规格/记录；phone-requirement → 规格/记录 | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 尚未设计第三方登录/首次无关联建号/短信绑定手机号/手机号备选及取消、验证失败状态；全部按用户要求仅记录待开发，不计为被删除，也不擅自新增UI | 尚未设计 |
| verify-code / 验证身份 | 合并 | auth → auth；login-requirement → 规格/记录；phone-requirement → 规格/记录 | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 尚未设计第三方登录/首次无关联建号/短信绑定手机号/手机号备选及取消、验证失败状态；全部按用户要求仅记录待开发，不计为被删除，也不擅自新增UI | 尚未设计 |
| account-recovery / 账号恢复 | 合并 | account → account | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 无真实恢复验证、注销范围选择/进度/失败布局；未来启用账号前补，不能用本机清理替代 | 尚未设计 |
| account-security / 账号与安全 | 合并 | account → account | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| account-delete / 注销账号 | 合并 | account → account | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 无真实恢复验证、注销范围选择/进度/失败布局；未来启用账号前补，不能用本机清理替代 | 尚未设计 |
| profile-edit / 个人信息 | 合并 | me → me | 称呼有即时价值；生活阶段/长期关注不应为填资料而强制采集。 只保留称呼；交流偏好移settings；背景在实际任务中按需自愿说明，不恢复通用个人资料长表 | 真实遗漏 |
| settings / 设置 | 保留 | settings → settings；settings-preferences → settings | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 保留 |
| theme / 主题与呼吸效果 | 合并 | appearance → appearance；settings → settings；settings-preferences → settings | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| avatar / 自己的形象 | 合并 | appearance → appearance；settings → settings；settings-preferences → settings | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| avatar-editor / 形象编辑方案 | 删除 | appearance → appearance | 部件捏脸对自我理解主线无直接贡献，素材/组合/预览成本高；现有人物预设已满足更换外观。 不补回该旧页面或系统。保留已确认的详细人物、预设切换及主题独立；不扩部件编辑器 | 尚未设计 |
| display-settings / 阅读与可访问性 | 合并 | appearance → appearance；settings → settings；settings-preferences → settings | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| notification-settings / 通知偏好 | 合并 | reminders → 规格/记录 | 只有实际通知/提醒启用时才需偏好。 settings按实际通道提供开关；当前不制造未生效的通知选择 | 尚未设计 |
| privacy / 隐私与控制 | 保留 | privacy → privacy | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 保留 |
| privacy-policy / 隐私说明 | 合并 | privacy → privacy；support → support | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 需要真实隐私/协议长文、变更阅读、系统权限状态和拒绝后可用流程；当前说明不等于正式协议 | 尚未设计 |
| terms / 用户协议 | 合并 | privacy → privacy；support → support | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 需要真实隐私/协议长文、变更阅读、系统权限状态和拒绝后可用流程；当前说明不等于正式协议 | 尚未设计 |
| permission-settings / 系统权限 | 合并 | privacy → privacy；support → support | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 需要真实隐私/协议长文、变更阅读、系统权限状态和拒绝后可用流程；当前说明不等于正式协议 | 尚未设计 |
| data-center / 我的数据 | 合并 | data → data；data-transfer-flow → data | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| data-export / 导出资料 | 合并 | data → data；data-transfer-flow → data | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| data-import / 导入备份 | 合并 | data → data；data-transfer-flow → data | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| backup-sync / 备份与同步方案 | 合并 | sync → 规格/记录；data → data | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 无云备份/多设备状态、上传授权、恢复和关闭规则布局；未来明确同步范围时补 | 尚未设计 |
| sync-conflicts / 处理资料冲突 | 合并 | sync → 规格/记录；data-transfer-flow → data | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 保留本机/采用导入/保留两份的逐对象冲突选择未设计；拒绝覆盖不等于已解决冲突 | 尚未设计 |
| clear-data / 清理本机数据 | 合并 | data → data；data-delete-flow → data | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| help / 帮助与反馈 | 合并 | support → support | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| help-article / 使用说明 | 合并 | support → support | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| feedback / 提交反馈 | 合并 | support → support | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 原提交→feedbackId→进度/回复/补充说明没有在线闭环设计；需与支持服务同步，不得把导出文本当已反馈 | 尚未设计 |
| feedback-detail / 反馈进度 | 合并 | support → support | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 原提交→feedbackId→进度/回复/补充说明没有在线闭环设计；需与支持服务同步，不得把导出文本当已反馈 | 尚未设计 |
| notifications / 消息 | 合并 | notifications → 规格/记录 | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 缺消息列表、已读、详情、跳回原对象及关闭提醒布局；通知启用时补 | 尚未设计 |
| notification-detail / 消息详情 | 合并 | notifications → 规格/记录 | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 缺消息列表、已读、详情、跳回原对象及关闭提醒布局；通知启用时补 | 尚未设计 |
| about / 关于产品 | 合并 | support → support | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| membership / 会员与权益 | 合并 | membership → membership | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| plan-detail / 会员方案详情 | 合并 | membership → membership | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| checkout / 确认开通（演示） | 保留 | checkout → checkout | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 保留 |
| payment-result / 支付结果 | 合并 | order → order?id=DEMO-ANNUAL-001；orders → orders | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| orders / 订单记录 | 保留 | orders → orders；order → order?id=DEMO-ANNUAL-001 | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 保留 |
| order-detail / 订单详情 | 合并 | order → order?id=DEMO-ANNUAL-001；orders → orders | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| refund-request / 申请退款 | 合并 | order → order?id=DEMO-ANNUAL-001；orders → orders | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| refund-status / 退款进度 | 合并 | order → order?id=DEMO-ANNUAL-001；orders → orders | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 按现有宿主补齐上述未覆盖能力；不因旧ID数量强拆页面 | 合并 |
| purchase-restore / 恢复购买 | 合并 | membership → membership | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 缺渠道/账号核验→旧单查询→权益恢复、手动续费或取消自动续订的具体状态；渠道规则待定不得假造 | 尚未设计 |
| subscription-settings / 续费管理方案 | 合并 | membership → membership | 支撑已确认的探索→有依据结果→情境交流→可控记忆→小尝试回看，或其必要数据/恢复/权限/交易配套；只保留对应真实场景。 缺渠道/账号核验→旧单查询→权益恢复、手动续费或取消自动续订的具体状态；渠道规则待定不得假造 | 尚未设计 |

## 6. 动作与实现证据边界

551/551动作键与原refined-routes精确一致，JSON逐条含稳定ID、必要文案、旧目标、对象参数、新宿主/目标、价值裁决、保留/合并/删除去向及验收约束。45条附当前具体静态实现入口；全部551条本轮未逐动作运行验收。

只读追溯过程先逐任务人工判断价值与能力，再按动作对象和目标关联；不以名字相似判定覆盖。具体动作无证据时标未证实。当前保留/合并行也可能含未做完子能力；JSON的missingCapabilities保留这些边界。

历史来源为2026-10-01完整结构版与路由收拢基线；当前对账源码固定481e89a。网页只呈现必要产品追溯摘要和动作，不展示原始源码、私有链接或工作日志。

## 7. 后台22职责独立映射

| 原职责 | 现服务责任域 | 旧必要操作 |
|---|---|---|
| dashboard / 运营与服务概览 | BR-007 | 刷新概览；查看待处理异常 |
| users / 用户列表 | BR-001 | 查询账号；打开用户详情 |
| user-detail / 用户详情与状态 | BR-001 | 读取账号摘要；限制指定账号能力；解除账号限制 |
| access / 后台角色与权限 | BR-001, BR-008 | 查看权限矩阵；调整指定管理权限；撤销指定授权 |
| plans / 会员方案与功能范围 | BR-003 | 比较方案版本；保存方案草稿；启用已明确的方案版本 |
| entitlements / 用户权益与补偿记录 | BR-001, BR-003 | 查询权益来源；追加人工权益补偿；撤回错误的人工补偿 |
| quota / AI 共享额度与调整账本 | BR-002 | 查询共享额度明细；追踪关联 AI 任务；追加额度纠正 |
| ai-tasks / AI 任务列表 | BR-002 | 查询任务；打开任务详情 |
| ai-task-detail / AI 任务详情与恢复 | BR-002 | 重新核验任务终态；请求停止指定任务；恢复已有结果交付 |
| orders / 订单列表 | BR-003 | 查找订单；打开订单详情 |
| order-detail / 订单详情 | BR-003 | 核对关联记录；取消确认未支付的订单；转支付核验 |
| payments / 支付渠道核验 | BR-003 | 查询渠道交易状态；重新处理已验证回执；查看回执与订单差异 |
| refunds / 退款申请与执行 | BR-003 | 查看退款依据；按已确定规则发起渠道退款；记录处理说明；核验渠道退款结果 |
| reconciliation / 交易与权益对账 | BR-003 | 生成只读差异视图；查看单笔差异证据；记录已核验的处理结论 |
| content-versions / 题库与内容版本 | BR-004 | 检查内容包元数据；登记待分发版本；开放具备依据的内容版本；停止新下载指定版本 |
| models / 模型路由与连接配置 | BR-002, BR-008 | 查看配置与可用性；保存模型配置草稿；切换指定业务的配置版本；暂停指定 AI 路由 |
| risks / 异常与滥用处理 | BR-002, BR-007 | 查看脱敏异常证据；添加有时限的范围限制；解除或到期回收限制 |
| support / 反馈与支持工单 | BR-005 | 查看工单与授权附件；保存处理回复；更新工单进度 |
| announcements / 公告与服务提示 | BR-005 | 预览移动端公告；保存公告草稿；发布指定范围公告；撤下错误公告 |
| privacy-requests / 资料与账号权利请求 | BR-006 | 核对请求与资料范围；执行明确范围的资料请求；保存范围与结果说明 |
| audit / 管理操作与变更记录 | BR-008 | 查找操作链；查看变更前后摘要；导出限定范围的审计摘要 |
| system-settings / 服务设置与边界 | BR-008 | 查看配置与消费者；保存运行配置草稿；启用指定配置版本 |

原22后台职责不从119移动职责中扣除。8责任域不是8个已实现后台页；按真实功能启用，仅做必要身份、额度、交易、内容、支持、数据控制、运行与追溯，不造大型运营控制台。

## 8. 未决

- 用户口述“最初100多页”未附确切版本；已核实当前119节点与更早100物理页两种来源，不能擅自认定仅指其中之一
- 旧轻量探索是否完全被最新简化版16PF覆盖，尚缺明确范围取舍；暂不合并抹除
- 703/725运行时计数是旧文档批次口径，本轮仅复算119/107/12/551；不宣称逐个旧运行时事件全验收
- 全部551显式动作都定位语义去向；只读静态入口证据不替代逐动作浏览器/正式APP业务验收
- 正式题源、真实身份、AI、支付/退款、通知和云同步仍未接入；设计待实现不是本轮删除许可
- 本轮价值删除针对当前无明确场景的独立模块；不是对未来任意新增具体场景的永久禁令，也不替代已明确内容或账号/支付需求


## 公开证据说明

历史分为测评与探索、个人助理与长期理解、个人/账号/数据/交易及后台配套四类。119职责与551显式动作已按原收拢规则复算；22后台职责/66动作独立核对。公开摘要提供计数口径与逐项去向，原始证据独立保存。网页只使用本公开版本，不能改用含私有链接的完整追溯文件。
